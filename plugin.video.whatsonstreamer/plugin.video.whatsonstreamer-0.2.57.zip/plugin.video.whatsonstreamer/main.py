import os
import sqlite3
import sys
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
from datetime import datetime, timezone, date

from resources.lib.simkl_api import SimklApi
from resources.lib.tmdb_api import TmdbApi
from resources.lib.alldebrid_api import AllDebridApi
from resources.lib.local_media import LocalMediaApi
from resources.lib.iptv_api import IptvApi
from resources.lib.iptv_http import get_ua as get_iptv_ua
from resources.lib.ui import get_params, build_url, add_folder, add_item, end_dir
from resources.lib import livetv
from resources.lib import iptv_profiles
from resources.lib import settings_reset
from resources.lib import legacy_import
from resources.lib import recommendations
from resources.lib import genres as genre_lists


ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo("path")
MEDIA_PATH = f"{ADDON_PATH}/resources/media"


HANDLE = int(sys.argv[1])

# --------------------------
# Logging / utility
# --------------------------
def log(msg):
    xbmc.log(f"[WhatsOnStreamer] {msg}", xbmc.LOGINFO)


def log_bug(params):
    """The 'Log Bug' item every screen gets for free (see ui.py's end_dir()).
    Free-text note field for jotting down something wrong on the spot (e.g.
    a wrong episode selection) to troubleshoot later, with the exact screen
    it was clicked from and a timestamp recorded automatically."""
    context = params.get("context", "")
    text = xbmcgui.Dialog().input("Log Bug - describe the issue", type=xbmcgui.INPUT_ALPHANUM)
    if not text or not text.strip():
        return

    profile = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    if not xbmcvfs.exists(profile):
        xbmcvfs.mkdirs(profile)
    log_path = profile.rstrip("/\\") + "/bug_log.txt"

    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    entry = f"--- {ts} ---\nScreen: {context}\n{text.strip()}\n\n"
    try:
        # xbmcvfs.File's 'a' (append) mode isn't reliably supported - confirmed
        # live: it silently no-ops instead of raising, so read-then-rewrite the
        # whole file instead, which only relies on the well-supported 'r'/'w'.
        existing = ""
        if xbmcvfs.exists(log_path):
            rf = xbmcvfs.File(log_path, 'r')
            existing = rf.read()
            rf.close()
        wf = xbmcvfs.File(log_path, 'w')
        wf.write(existing + entry)
        wf.close()
    except Exception as e:
        xbmc.log(f"[WhatsOnStreamer] log_bug write failed: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("WhatsOnStreamer", "Failed to save bug note", xbmcgui.NOTIFICATION_ERROR)
        return

    xbmcgui.Dialog().notification("WhatsOnStreamer", "Bug logged", xbmcgui.NOTIFICATION_INFO, 1500)


def parse_sxxexx(s):
    # "S02E05" -> (2,5)
    if not s:
        return None
    try:
        u = s.strip().upper()
        if not (u.startswith("S") and "E" in u):
            return None
        a, b = u[1:].split("E", 1)
        return int(a), int(b)
    except Exception:
        return None


def _parse_iso_utc_datetime(s):
    """
    Best-effort parse SIMKL timestamps like:
      - 2026-03-03T20:55:27Z
      - 2026-03-03T20:55:27.000Z
    Returns datetime (naive UTC) or None.
    """
    if not s:
        return None
    try:
        txt = str(s).strip()
        if txt.endswith("Z"):
            # remove milliseconds if present
            if "." in txt:
                txt = txt.split(".", 1)[0] + "Z"
            return datetime.strptime(txt, "%Y-%m-%dT%H:%M:%SZ")
        # fallback: take first 19 chars "YYYY-MM-DDTHH:MM:SS"
        if "T" in txt and len(txt) >= 19:
            return datetime.strptime(txt[:19], "%Y-%m-%dT%H:%M:%S")
        return None
    except Exception:
        return None


def _parse_ymd_date(s):
    """
    Parse YYYY-MM-DD to date or None.
    """
    if not s:
        return None
    try:
        return datetime.strptime(str(s)[:10], "%Y-%m-%d").date()
    except Exception:
        return None


# --------------------------
# Local-date countdown helpers (Upcoming list)
# --------------------------
def _today_local_date():
    # "from today" should be based on the Kodi machine's local date
    return date.today()


def _days_until(iso_yyyy_mm_dd):
    """
    Returns number of days until given YYYY-MM-DD date string.
    - None if missing/invalid.
    - Negative if in the past (we keep it in Upcoming, but label becomes title-only).
    """
    if not iso_yyyy_mm_dd:
        return None
    try:
        target = datetime.strptime(iso_yyyy_mm_dd, "%Y-%m-%d").date()
        return (target - _today_local_date()).days
    except Exception:
        return None


# --------------------------
# Homelander integration
# --------------------------
def build_homelander_url(action, imdb, tmdb, tvshowtitle, year, season=None, episode=None):
    params = {
        "action": action,
        "imdb": imdb or "",
        "tmdb": tmdb or "",
        "tvshowtitle": tvshowtitle or "",
        "year": str(year or ""),
    }
    if season is not None:
        params["season"] = str(season)
    if episode is not None:
        params["episode"] = str(episode)
    qs = urllib.parse.urlencode(params, quote_via=urllib.parse.quote)
    return f"plugin://plugin.video.homelander/?{qs}"


def build_homelander_play_url(imdb, tmdb, tvshowtitle, year, season, episode, ep_title="", premiered=""):
    import json as _json
    params = {
        "action": "play",
        "title": ep_title or tvshowtitle or "",
        "year": str(year or ""),
        "imdb": imdb or "",
        "tmdb": tmdb or "",
        "season": str(season),
        "episode": str(episode),
        "tvshowtitle": tvshowtitle or "",
        "premiered": premiered or "",
        "meta": _json.dumps({}),
    }
    qs = urllib.parse.urlencode(params, quote_via=urllib.parse.quote)
    return f"plugin://plugin.video.homelander/?{qs}"


def _ensure_homelander_search_db():
    """Homelander's movieSearchterm action runs `DELETE FROM movies` on its
    search.1.db without creating the table first - only its interactive Search
    menu does that. On a fresh install (or an empty/reset db, as on dev: a
    0-byte file) the direct call crashes with 'no such table: movies' and the
    window opens empty. Create the table up front so our direct hand-off works."""
    try:
        path = os.path.join(
            xbmcvfs.translatePath("special://profile/addon_data/plugin.video.homelander"),
            "search.1.db",
        )
        os.makedirs(os.path.dirname(path), exist_ok=True)
        con = sqlite3.connect(path)
        try:
            con.execute("CREATE TABLE IF NOT EXISTS movies (ID Integer PRIMARY KEY AUTOINCREMENT, term)")
            con.commit()
        finally:
            con.close()
    except Exception as e:
        xbmc.log(f"[WhatsOnStreamer] Could not prepare Homelander search db: {e}", xbmc.LOGERROR)


def open_homelander(params):
    title = params.get("title", "")
    imdb = params.get("imdb", "")
    tmdb = params.get("tmdb", "")
    year = params.get("year", "")
    nxt = params.get("next", "")  # e.g. "S01E03" (may be empty)
    ep_title = params.get("ep_title", "")
    air_date = params.get("air_date", "")
    media_type = params.get("media_type", "tv")

    if media_type == "movie":
        _ensure_homelander_search_db()
        name = f"{title} ({year})" if year else title
        homelander_url = (
            "plugin://plugin.video.homelander/?action=movieSearchterm&name="
            + urllib.parse.quote(name)
        )
        xbmc.executebuiltin(f'ActivateWindow(10025,"{homelander_url}",return)')
        return

    season = None
    episode = None
    se = parse_sxxexx(nxt)
    if se:
        season, episode = se

    if season is not None and episode is not None:
        homelander_url = build_homelander_play_url(imdb, tmdb, title, year, season, episode, ep_title, air_date)
        xbmc.log(f"[WhatsOnStreamer] open_homelander play URL: {homelander_url}", xbmc.LOGINFO)
        xbmc.executebuiltin(f'RunPlugin("{homelander_url}")')
    else:
        homelander_url = build_homelander_url("seasons", imdb, tmdb, title, year)
        xbmc.log(f"[WhatsOnStreamer] open_homelander seasons URL: {homelander_url}", xbmc.LOGINFO)
        xbmc.executebuiltin(f'ActivateWindow(10025,"{homelander_url}",return)')


# --------------------------
# SIMKL posters
# --------------------------
def simkl_poster_url(poster_path, size_suffix="_m", ext=".webp"):
    """
    Build a SIMKL poster URL using SIMKL's recommended proxy and simkl.in domain.
    """
    if not poster_path:
        return None
    return f"https://wsrv.nl/?url=https://simkl.in/posters/{poster_path}{size_suffix}{ext}"


def tmdb_poster_url(poster_path, size_suffix="w342"):
    """
    Build a TMDB image URL for movie posters.
    """
    if not poster_path:
        return None
    return f"https://image.tmdb.org/t/p/{size_suffix}{poster_path}"


# --------------------------
# TMDB airdate helpers

def use_tmdb_airdates(addon):
    """
    airdate_source enum in settings:
    0 = SIMKL
    1 = TMDB
    """
    try:
        return addon.getSettingInt("airdate_source") == 1
    except Exception:
        return addon.getSettingString("airdate_source").strip() in ("1", "TMDB", "tmdb")


def tmdb_airdate_for_next(addon, tmdb_id, next_code):
    """
    next_code like "S01E03" -> query TMDB season details -> return YYYY-MM-DD or None.
    """
    if not tmdb_id or not next_code:
        return None
    se = parse_sxxexx(next_code)
    if not se:
        return None
    season, episode = se
    api = TmdbApi(addon)
    if not api.is_configured():
        return None
    try:
        return api.episode_air_date(int(tmdb_id), int(season), int(episode))
    except Exception as e:
        xbmc.log(f"[WhatsOnStreamer][TMDB] airdate lookup failed: {e}", xbmc.LOGERROR)
        return None


def tmdb_next_episode_airdate(addon, tmdb_id):
    """
    Uses TMDB TV details next_episode_to_air when available.
    """
    if not tmdb_id:
        return None
    api = TmdbApi(addon)
    if not api.is_configured():
        return None
    try:
        return api.next_episode_air_date(int(tmdb_id))
    except Exception as e:
        xbmc.log(f"[WhatsOnStreamer][TMDB] next_episode lookup failed: {e}", xbmc.LOGERROR)
        return None


# --------------------------
# Screens
# --------------------------
def show_root_menu():
    xbmcplugin.setPluginCategory(HANDLE, "WhatsOnStreamer")
    add_folder("[B]WhatsOnNow (Live TV)[/B]", "livetv_root", icon=f"{MEDIA_PATH}/on_now.png")
    add_folder("[B]WhatsUpNext (Series and Movies)[/B]", "whatsupnext_root", icon=f"{MEDIA_PATH}/new.png")
    add_folder("[B]Tools[/B]", "tools_root", icon=f"{MEDIA_PATH}/tools_diagnostics.png")
    end_dir()


def show_whatsupnext_menu():
    xbmcplugin.setPluginCategory(HANDLE, "WhatsUpNext")
    add_folder("New Episodes", "new", icon=f"{MEDIA_PATH}/new.png")
    add_folder("Upcoming Episodes", "upcoming", icon=f"{MEDIA_PATH}/upcoming.png")
    add_folder("Movies", "movies", icon=f"{MEDIA_PATH}/movies.png")
    add_folder("Add Shows and Movies", "add_content_menu", icon=f"{MEDIA_PATH}/favourites.png")
    add_folder("AllDebrid", "alldebrid_menu", icon=f"{MEDIA_PATH}/alldebrid.png")
    add_folder("Search", "search_menu", icon=f"{MEDIA_PATH}/search.png")
    end_dir()


def show_tools_menu():
    xbmcplugin.setPluginCategory(HANDLE, "Tools")
    add_folder("Authorize SIMKL", "auth", icon=f"{MEDIA_PATH}/auth.png")
    add_item("Live TV: Build info", url=build_url(action="livetv_build_info"))
    add_item("Live TV: Run auto-update now", url=build_url(action="svc_update"))
    add_item("Live TV: Test connection", url=build_url(action="livetv_test"))
    add_item("Live TV: Test local files", url=build_url(action="livetv_test_local"))
    add_item("Live TV: Manage IPTV Profiles", url=build_url(action="iptv_manage_profiles"))
    add_item("WhatsUpNext: Warm episode cache now", url=build_url(action="svc_warm_whatsupnext"))
    add_item("Import settings from WhatsOnNow / WhatsUpNext", url=build_url(action="settings_import"))
    add_item("Reset settings to defaults", url=build_url(action="settings_reset"))
    add_item("Open Settings", url=build_url(action="settings"))
    end_dir()


def show_new_episodes():
    xbmcplugin.setPluginCategory(HANDLE, "New Episodes")
    xbmcplugin.setContent(HANDLE, "tvshows")
    # Without this, Kodi silently re-sorts by whatever the skin's default/last
    # -used sort method is (usually Title) regardless of the order we build -
    # confirmed live on Recommended Movies. This list is deliberately ordered
    # by most-recently-watched first, not alphabetically.
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    addon = xbmcaddon.Addon()
    api = SimklApi(addon)

    if not api.is_authorized():
        add_item("Not authorized. Run 'Authorize SIMKL' first.")
        end_dir()
        return

    try:
        data = api.get_watching_shows()
        if addon.getSettingBool("debug_logging"):
            xbmc.log(f"[WhatsOnStreamer] /sync/all-items/shows/watching response: {data}", xbmc.LOGINFO)

        shows = data.get("shows", []) if isinstance(data, dict) else []
        if not shows:
            add_item("No items returned from WhatsOnStreamer list.")
            end_dir()
            return

        rows = []
        tmdb_enabled = use_tmdb_airdates(addon)

        for it in shows:
            show = it.get("show", {})
            ids = show.get("ids") or {}

            title = show.get("title", "Unknown title")
            year = show.get("year", "")
            imdb_id = ids.get("imdb", "")
            tmdb_id = ids.get("tmdb", "")
            simkl_id = ids.get("simkl", "")
            poster_path = show.get("poster")
            overview = show.get("overview") or ""

            # Ratings from extended=full response
            ratings = show.get("ratings") or {}
            simkl_r = ratings.get("simkl") or {}
            simkl_rating = simkl_r.get("rating") or show.get("rating") or 0.0
            simkl_votes = simkl_r.get("votes") or 0

            next_to_watch = it.get("next_to_watch")  # e.g. "S01E03" or None
            watched = it.get("watched_episodes_count") or 0
            total = it.get("total_episodes_count") or 0
            not_aired = it.get("not_aired_episodes_count") or 0

            aired_total = max(0, total - not_aired)
            new_count = max(0, aired_total - watched)

            if new_count <= 0:
                continue

            oldest = next_to_watch if next_to_watch else "unknown next episode"

            airdate = None
            if tmdb_enabled:
                airdate = tmdb_airdate_for_next(addon, tmdb_id, next_to_watch)

            # Sort key: SIMKL last_watched_at (most recent first)
            last_watched_at = it.get("last_watched_at")
            last_dt = _parse_iso_utc_datetime(last_watched_at)

            rows.append((last_dt, new_count, title, oldest, airdate, poster_path, imdb_id, tmdb_id, year, simkl_id, overview, simkl_rating, simkl_votes))

        if not rows:
            add_item("You're all caught up ✅ (no aired unwatched episodes).")
            end_dir()
            return

        # Sort by most recently watched (descending). Unknown last_watched_at goes bottom.
        def _sort_key(r):
            last_dt, _, title = r[0], r[1], r[2]
            if last_dt is None:
                return (1, float("inf"), title.lower())
            return (0, -last_dt.timestamp(), title.lower())

        rows.sort(key=_sort_key)

        show_posters = addon.getSettingBool("show_posters")
        tmdb_api = TmdbApi(addon)

        for last_dt, new_count, title, oldest, airdate, poster_path, imdb_id, tmdb_id, year, simkl_id, overview, simkl_rating, simkl_votes in rows:
            if airdate:
                label = f"{title} — {new_count} new — {oldest} ({airdate})"
            else:
                label = f"{title} — {new_count} new — {oldest}"

            art = None
            if show_posters:
                purl = simkl_poster_url(poster_path)
                if purl:
                    art = {"thumb": purl, "poster": purl, "icon": purl}

            se = parse_sxxexx(oldest)
            url = build_url(
                action="show_season_episodes",
                title=title,
                imdb=imdb_id,
                tmdb=tmdb_id,
                year=year,
                next=oldest if oldest != "unknown next episode" else "",
                season_num=se[0] if se else 1,
                simkl_poster=poster_path or "",
                simkl_id=simkl_id,
            )

            # TMDB details — uses cache (2-day TTL), fetches only on first encounter
            tmdb_vote_avg = None
            show_cast = []
            if tmdb_id and tmdb_api.is_configured():
                try:
                    tmdb_det = tmdb_api.tv_details(int(tmdb_id))
                    tmdb_vote_avg = tmdb_det.get("vote_average")
                    if not overview:
                        overview = tmdb_det.get("overview") or ""
                    show_cast = [
                        {
                            "name": c["name"],
                            "role": c.get("character") or (c.get("roles") or [{}])[0].get("character", ""),
                            "thumbnail": f"https://image.tmdb.org/t/p/w185{c['profile_path']}" if c.get("profile_path") else "",
                        }
                        for c in (tmdb_det.get("credits", {}).get("cast") or [])[:15]
                    ]
                except Exception as e:
                    xbmc.log(f"[WhatsOnStreamer] TMDB tv_details failed for {title}: {e}", xbmc.LOGERROR)

            # SIMKL show-details cache — last-resort for shows with no TMDB id
            if not overview and simkl_id:
                simkl_cached = api.get_show_details_if_cached(int(simkl_id))
                if simkl_cached:
                    overview = simkl_cached.get("overview") or ""
                    if not simkl_rating:
                        r = (simkl_cached.get("ratings") or {}).get("simkl") or {}
                        simkl_rating = r.get("rating") or simkl_cached.get("rating") or 0.0
                        simkl_votes = r.get("votes") or 0

            # Build plot: overview + ratings footer
            rating_parts = []
            if simkl_rating:
                votes_str = f"  ({simkl_votes:,})" if simkl_votes else ""
                rating_parts.append(f"SIMKL  {simkl_rating:.1f}/10{votes_str}")
            if tmdb_vote_avg:
                rating_parts.append(f"TMDB  {tmdb_vote_avg:.1f}/10")
            plot = overview
            if rating_parts:
                plot = (plot + "\n\n" if plot else "") + "  ·  ".join(rating_parts)

            # Kodi's list view renders ListItem.Title (from the video info tag)
            # in preference to ListItem.Label whenever a video info tag is set -
            # confirmed 2026-09-16 after 0.2.46 started registering a sort method,
            # which made Kodi treat this as a proper video list instead of a
            # generic file list. Title must carry the same "X new - SxxExx
            # (date)" suffix as label, or that text silently disappears in List
            # view even though the plugin directory listing (and Label) has it.
            info = {"title": label, "tvshowtitle": title}
            if plot:
                info["plot"] = plot
            if simkl_rating:
                info["rating"] = float(simkl_rating)
            if simkl_votes:
                info["votes"] = str(simkl_votes)
            if simkl_id:
                info["trailer"] = build_url(action="play_trailer", title=title, simkl_id=simkl_id, kind="show")

            ctx = [("Show Information", "Action(Info)")]
            if se:
                ctx.insert(0, ("Play", f"RunPlugin({build_url(action='play_episode_default', title=title, season=se[0], episode=se[1], imdb=imdb_id, tmdb=tmdb_id)})"))
            if simkl_id:
                ctx.append(("Watch Trailer", f"RunPlugin({build_url(action='play_trailer', title=title, simkl_id=simkl_id, kind='show')})"))
                ctx.append(("Mark as Watched", f"RunPlugin({build_url(action='recommended_watched', kind='show', simkl_id=simkl_id, title=title)})"))
                ctx.append(("Remove", f"RunPlugin({build_url(action='recommended_remove', kind='show', simkl_id=simkl_id, title=title)})"))
            add_item(label, url=url, info=info, art=art, is_folder=True, context_menu=ctx, cast=show_cast or None)

        end_dir()

    except Exception as e:
        xbmc.log(f"[WhatsOnStreamer] New Episodes failed: {e}", xbmc.LOGERROR)
        add_item("Failed to fetch SIMKL data. Check kodi.log.")
        end_dir()


def show_upcoming():
    """
    NEW SORT RULE:
      - Sort by newest release date (airdate descending).
    """
    xbmcplugin.setPluginCategory(HANDLE, "Upcoming Episodes")
    xbmcplugin.setContent(HANDLE, "tvshows")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    addon = xbmcaddon.Addon()
    tmdb_api = TmdbApi(addon)
    api = SimklApi(addon)

    if not api.is_authorized():
        add_item("Not authorized. Run 'Authorize SIMKL' first.")
        end_dir()
        return

    try:
        data = api.get_watching_shows()
        if addon.getSettingBool("debug_logging"):
            xbmc.log(f"[WhatsOnStreamer] /sync/all-items/shows/watching response: {data}", xbmc.LOGINFO)

        shows = data.get("shows", []) if isinstance(data, dict) else []
        if not shows:
            add_item("No items returned from WhatsOnStreamer list.")
            end_dir()
            return

        rows = []
        tmdb_enabled = use_tmdb_airdates(addon)

        for it in shows:
            show = it.get("show", {})
            ids = show.get("ids") or {}

            title = show.get("title", "Unknown title")
            tmdb_id = ids.get("tmdb", "")
            simkl_id = ids.get("simkl", "")
            poster_path = show.get("poster")

            watched = it.get("watched_episodes_count") or 0
            total = it.get("total_episodes_count") or 0
            not_aired = it.get("not_aired_episodes_count") or 0

            # Same logic as before:
            aired_total = max(0, total - not_aired)
            new_aired_unwatched = max(0, aired_total - watched)

            # Upcoming shows only: caught up on aired episodes, but has future episodes
            if new_aired_unwatched != 0:
                continue
            if not_aired <= 0:
                continue

            next_to_watch = it.get("next_to_watch") or ""

            airdate = None
            if tmdb_enabled:
                airdate = tmdb_airdate_for_next(addon, tmdb_id, next_to_watch)
                if not airdate:
                    airdate = tmdb_next_episode_airdate(addon, tmdb_id)

            rows.append((not_aired, title, next_to_watch, airdate, poster_path, simkl_id, tmdb_id))

        if not rows:
            add_item("No upcoming episodes found (or you have new aired episodes instead).")
            end_dir()
            return

        # Sort by newest known airdate first (descending). Unknown dates go bottom.
        def _sort_key(row):
            _, title, _, airdate, _, _, _ = row
            d = _parse_ymd_date(airdate)
            if d is None:
                return (1, float("inf"), title.lower())
            return (0, d.toordinal(), title.lower())

        rows.sort(key=_sort_key)

        show_posters = addon.getSettingBool("show_posters")

        for _, title, _, airdate, poster_path, simkl_id, tmdb_id in rows:
            # Keep your existing label rules/countdown, just change ordering.
            d = _days_until(airdate)

            if d is None or d < 0:
                label = f"{title}"
            elif d < 3:
                target_d = _parse_ymd_date(airdate)
                end_of_day = datetime(target_d.year, target_d.month, target_d.day, 23, 59, 59)
                hours = int((end_of_day - datetime.now()).total_seconds() / 3600)
                label = f"{title} — {hours} hours — ({airdate})"
            else:
                label = f"{title} — {d} days — ({airdate})"

            art = None
            if show_posters:
                url = simkl_poster_url(poster_path)
                if url:
                    art = {"thumb": url, "poster": url, "icon": url}

            overview = ""
            vote_average = 0.0
            show_cast = []
            if tmdb_id and tmdb_api.is_configured():
                try:
                    tmdb_det = tmdb_api.tv_details(int(tmdb_id))
                    overview = tmdb_det.get("overview") or ""
                    vote_average = tmdb_det.get("vote_average") or 0.0
                    show_cast = [
                        {
                            "name": c["name"],
                            "role": c.get("character") or (c.get("roles") or [{}])[0].get("character", ""),
                            "thumbnail": f"https://image.tmdb.org/t/p/w185{c['profile_path']}" if c.get("profile_path") else "",
                        }
                        for c in (tmdb_det.get("credits", {}).get("cast") or [])[:15]
                    ]
                except Exception as e:
                    xbmc.log(f"[WhatsOnStreamer] TMDB tv_details failed for {title}: {e}", xbmc.LOGERROR)

            # See show_new_episodes() for why this must be `label`, not the
            # bare title - Kodi's list view prefers ListItem.Title over Label
            # once a video info tag is set, silently dropping the "X days -
            # (date)" suffix otherwise.
            info = {"title": label, "tvshowtitle": title}
            if overview:
                info["plot"] = overview
            if vote_average:
                info["rating"] = float(vote_average)
            if simkl_id:
                info["trailer"] = build_url(action="play_trailer", title=title, simkl_id=simkl_id, kind="show")

            ctx = [("Show Information", "Action(Info)")]
            if simkl_id:
                ctx.append(("Watch Trailer", f"RunPlugin({build_url(action='play_trailer', title=title, simkl_id=simkl_id, kind='show')})"))
                ctx.append(("Mark as Watched", f"RunPlugin({build_url(action='recommended_watched', kind='show', simkl_id=simkl_id, title=title)})"))
                ctx.append(("Remove", f"RunPlugin({build_url(action='recommended_remove', kind='show', simkl_id=simkl_id, title=title)})"))
            add_item(label, info=info, art=art, context_menu=ctx, cast=show_cast or None)

        end_dir()

    except Exception as e:
        xbmc.log(f"[WhatsOnStreamer] Upcoming failed: {e}", xbmc.LOGERROR)
        add_item("Failed to fetch SIMKL data. Check kodi.log.")
        end_dir()


def show_movies():
    xbmcplugin.setPluginCategory(HANDLE, "Movies")
    xbmcplugin.setContent(HANDLE, "movies")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    addon = xbmcaddon.Addon()
    api = SimklApi(addon)

    if not api.is_authorized():
        add_item("Not authorized. Run 'Authorize SIMKL' first.")
        end_dir()
        return

    try:
        data = api.get_plan_movies()
        if addon.getSettingBool("debug_logging"):
            xbmc.log(f"[WhatsOnStreamer] /sync/all-items/movies/plan FULL response: {data}", xbmc.LOGINFO)

        movies = []
        if isinstance(data, dict):
            if isinstance(data.get("movies"), list):
                movies = data["movies"]
                if addon.getSettingBool("debug_logging"):
                    xbmc.log(f"[WhatsOnStreamer] Extracted {len(movies)} movies from 'movies' key", xbmc.LOGINFO)
            elif isinstance(data.get("items"), list):
                movies = data["items"]
                if addon.getSettingBool("debug_logging"):
                    xbmc.log(f"[WhatsOnStreamer] Extracted {len(movies)} movies from 'items' key", xbmc.LOGINFO)
            elif isinstance(data.get("data"), list):
                movies = data["data"]
                if addon.getSettingBool("debug_logging"):
                    xbmc.log(f"[WhatsOnStreamer] Extracted {len(movies)} movies from 'data' key", xbmc.LOGINFO)
        elif isinstance(data, list):
            movies = data
            if addon.getSettingBool("debug_logging"):
                xbmc.log(f"[WhatsOnStreamer] Data is already a list with {len(movies)} items", xbmc.LOGINFO)

        def _item_is_plan_movie(item):
            if not isinstance(item, dict):
                return False
            status = item.get("status") or item.get("list")
            if not status:
                movie = item.get("movie") or item.get("film") or {}
                status = movie.get("status") or movie.get("list")
            if not status:
                return False
            return str(status).strip().lower() in (
                "plan",
                "plan to watch",
                "planned",
                "plan_to_watch",
                "plantowatch",
                "watchlist",
            )

        movies = [item for item in movies if _item_is_plan_movie(item)]
        
        if addon.getSettingBool("debug_logging"):
            xbmc.log(f"[WhatsOnStreamer] After status filter: {len(movies)} movies remaining", xbmc.LOGINFO)
            if movies:
                xbmc.log(f"[WhatsOnStreamer] First movie for debug: {movies[0]}", xbmc.LOGINFO)

        def _movie_like(item):
            if not isinstance(item, dict):
                return False
            if item.get("movie") or item.get("film"):
                return True
            if item.get("title") or item.get("year") or item.get("ids"):
                return True
            return False

        if not movies and isinstance(data, dict):
            for key, value in data.items():
                if isinstance(value, list) and any(_movie_like(x) for x in value):
                    movies = value
                    if addon.getSettingBool("debug_logging"):
                        xbmc.log(f"[WhatsOnStreamer] fallback movie list from key={key}", xbmc.LOGINFO)
                    break

        if not movies:
            add_item("No movies found in your SIMKL Plan to Watch list.")
            end_dir()
            return

        def _extract_movie_object(item):
            if not isinstance(item, dict):
                return {}
            movie = item.get("movie") or item.get("film") or item
            if not isinstance(movie, dict):
                return {}
            return movie

        movies = sorted(
            movies,
            key=lambda item: (_extract_movie_object(item).get("title", "").lower())
        )
        tmdb_enabled = use_tmdb_airdates(addon)
        show_posters = addon.getSettingBool("show_posters")

        for it in movies:
            movie = _extract_movie_object(it)
            ids = movie.get("ids") or {}

            title = movie.get("title") or movie.get("name") or "Unknown title"
            year = movie.get("year", "")
            imdb_id = ids.get("imdb", "")
            tmdb_id = ids.get("tmdb", "")
            simkl_id = ids.get("simkl", "")
            poster_path = movie.get("poster") or movie.get("poster_path")
            overview = movie.get("overview") or movie.get("plot") or ""
            release_date = movie.get("released") or movie.get("release_date") or ""

            tmdb_art = None
            vote_average = 0.0
            vote_count = 0
            runtime = None
            genres = []
            movie_cast = []
            if tmdb_enabled and tmdb_id:
                try:
                    details = TmdbApi(addon).movie_details(int(tmdb_id))
                    if not overview:
                        overview = details.get("overview") or overview
                    if not release_date:
                        release_date = details.get("release_date") or release_date
                    tmdb_art = tmdb_poster_url(details.get("poster_path"))
                    vote_average = details.get("vote_average") or 0.0
                    vote_count = details.get("vote_count") or 0
                    runtime = details.get("runtime")
                    genres = [g["name"] for g in (details.get("genres") or [])]
                    movie_cast = [
                        {
                            "name": c["name"],
                            "role": c.get("character") or "",
                            "thumbnail": f"https://image.tmdb.org/t/p/w185{c['profile_path']}" if c.get("profile_path") else "",
                        }
                        for c in (details.get("credits", {}).get("cast") or [])[:15]
                    ]
                except Exception as e:
                    xbmc.log(f"[WhatsOnStreamer][TMDB] movie details lookup failed: {e}", xbmc.LOGERROR)

            label = title
            if year:
                label = f"{title} ({year})"
            if release_date and release_date != year:
                label = f"{label} — {release_date}"

            art = None
            if show_posters:
                if tmdb_art:
                    art = {"thumb": tmdb_art, "poster": tmdb_art, "icon": tmdb_art}
                else:
                    url = simkl_poster_url(poster_path)
                    if url:
                        art = {"thumb": url, "poster": url, "icon": url}

            info = {"title": title}
            if year:
                info["year"] = str(year)
            if overview:
                info["plot"] = overview
            if vote_average:
                info["rating"] = float(vote_average)
            if vote_count:
                info["votes"] = str(vote_count)
            if runtime:
                info["duration"] = int(runtime) * 60
            if genres:
                info["genre"] = ", ".join(genres)
            if simkl_id:
                # Populates Kodi's native "Play Trailer" button on the info
                # dialog itself, not just the right-click menu - Kodi treats
                # this as a playable path and PlayMedia()s it when clicked,
                # which chains into play_trailer()'s own PlayMedia hand-off
                # to plugin.video.youtube.
                info["trailer"] = build_url(action="play_trailer", title=title, simkl_id=simkl_id, kind="movie")

            url = _movie_play_url(title, imdb_id, tmdb_id, year)

            ctx = [
                ("Movie Information", "Action(Info)"),
                *_movie_play_menu(title, imdb_id, tmdb_id, year),
            ]
            if simkl_id:
                ctx.append(("Watch Trailer", f"RunPlugin({build_url(action='play_trailer', title=title, simkl_id=simkl_id, kind='movie')})"))
                ctx.append(("Mark as Watched", f"RunPlugin({build_url(action='recommended_watched', kind='movie', simkl_id=simkl_id, title=title)})"))
                ctx.append(("Remove Movie", f"RunPlugin({build_url(action='recommended_remove', kind='movie', simkl_id=simkl_id, title=title)})"))

            add_item(label, url=url, info=info, art=art, is_folder=False, context_menu=ctx, cast=movie_cast or None)

        end_dir()

    except Exception as e:
        xbmc.log(f"[WhatsOnStreamer] Movies failed: {e}", xbmc.LOGERROR)
        add_item("Failed to fetch SIMKL data. Check kodi.log.")
        end_dir()


def show_add_content_menu():
    xbmcplugin.setPluginCategory(HANDLE, "Add Shows and Movies")
    add_folder("Movies", "add_movies_menu", icon=f"{MEDIA_PATH}/movies.png")
    add_folder("Series", "add_series_menu", icon=f"{MEDIA_PATH}/new.png")
    end_dir()


def show_add_movies_menu():
    xbmcplugin.setPluginCategory(HANDLE, "Add Movies")
    add_folder("Recommended", "recommended_movies", icon=f"{MEDIA_PATH}/favourites.png")
    add_folder("Genres", "movie_genres_menu", icon=f"{MEDIA_PATH}/groups.png")
    end_dir()


def show_add_series_menu():
    xbmcplugin.setPluginCategory(HANDLE, "Add Series")
    add_folder("Recommended", "recommended_shows", icon=f"{MEDIA_PATH}/favourites.png")
    add_folder("Genres", "tv_genres_menu", icon=f"{MEDIA_PATH}/groups.png")
    end_dir()


def show_movie_genres_menu():
    xbmcplugin.setPluginCategory(HANDLE, "Genres")
    for name, genre_id in genre_lists.MOVIE_GENRES:
        url = build_url(action="movie_genre_titles", genre_id=genre_id, genre_name=name)
        add_item(name, url=url, is_folder=True, art={"icon": f"{MEDIA_PATH}/movies.png"})
    end_dir()


def show_tv_genres_menu():
    xbmcplugin.setPluginCategory(HANDLE, "Genres")
    for name, genre_id in genre_lists.TV_GENRES:
        url = build_url(action="tv_genre_titles", genre_id=genre_id, genre_name=name)
        add_item(name, url=url, is_folder=True, art={"icon": f"{MEDIA_PATH}/new.png"})
    end_dir()


def _discover_top_rated(tmdb, kind: str, genre_id: int, limit=100, exclude_tmdb_ids=None):
    """Merges TMDB discover pages (20 results/page, so enough pages for `limit`
    plus one buffer page) for one genre - already sorted top-rated first
    per-page by the API - into a single de-duplicated, re-sorted list. Multiple
    pages are pulled both because a single page can't be trusted to stay sorted
    across the merge boundary, and because exclude_tmdb_ids can otherwise leave
    fewer than `limit` results once already-tracked titles are filtered out.

    Excludes Animation from every other genre (e.g. an animated sci-fi show
    is tagged with both Animation and Sci-Fi & Fantasy on TMDB) so it only
    ever shows up under its own Animation bucket, not doubled up elsewhere.

    `exclude_tmdb_ids` drops anything already in the account's SIMKL lists
    (see SimklApi.known_tmdb_ids()) so Genre browsing only ever suggests
    titles that aren't already being watched/tracked."""
    fetch = tmdb.discover_movies if kind == "movie" else tmdb.discover_tv
    without_genres = None if genre_id == genre_lists.ANIMATION_GENRE_ID else genre_lists.ANIMATION_GENRE_ID
    exclude_tmdb_ids = exclude_tmdb_ids or set()
    results = []
    seen_ids = set()
    pages_needed = -(-limit // 20) + 1  # ceil(limit / 20) plus one buffer page
    for page in range(1, pages_needed + 1):
        data = _safe_tmdb(lambda p=page: fetch(genre_id, page=p, without_genres=without_genres), f"discover {kind} genre={genre_id} page={page}")
        for r in (data or {}).get("results") or []:
            rid = r.get("id")
            if not rid or rid in seen_ids or str(rid) in exclude_tmdb_ids:
                continue
            seen_ids.add(rid)
            results.append(r)
    results.sort(key=lambda r: r.get("vote_average") or 0.0, reverse=True)
    return results[:limit]


def _plot_with_rating_header(overview, year, rating, votes, source="TMDB"):
    """Prepends a 'Year  •  <source> rating' line to the overview so it's
    visible in the plot/description panel itself, rather than relying on the
    skin to surface the separate year/rating info fields. Used by both
    Genre-browse items (source='TMDB') and Recommended items (source='SIMKL')."""
    bits = []
    if year:
        bits.append(str(year))
    if rating:
        votes_str = f"  ({votes:,} votes)" if votes else ""
        bits.append(f"{source} {rating:.1f}/10{votes_str}")
    header = "  •  ".join(bits)
    if header and overview:
        return f"{header}\n\n{overview}"
    return header or overview


def _safe_tmdb(fn, label):
    try:
        return fn()
    except Exception as e:
        xbmc.log(f"[WhatsOnStreamer][TMDB] {label} failed: {e}", xbmc.LOGERROR)
        return None


def _movie_play_url(title, imdb, tmdb, year):
    """Click target for a movie in any list: play straight away (local -> IPTV ->
    Homelander, see play_movie_default) instead of opening the one-item
    show_movie page first."""
    return build_url(action="play_movie_default", title=title, imdb=imdb, tmdb=str(tmdb), year=year)


def _movie_play_menu(title, imdb, tmdb, year):
    """Right-click 'Play via ...' choices that used to live on the show_movie page."""
    hl_url = build_url(action="open_homelander", title=title, imdb=imdb, tmdb=str(tmdb), year=year, media_type="movie")
    return [
        ("Play via AllDebrid", f"RunPlugin({build_url(action='play_alldebrid_movie', title=title)})"),
        ("Play via Homelander", f"RunPlugin({hl_url})"),
        ("Play via IPTV", f"RunPlugin({build_url(action='play_iptv_movie', title=title)})"),
    ]


def _tmdb_cast(details):
    return [
        {
            "name": c["name"],
            "role": c.get("character") or "",
            "thumbnail": f"https://image.tmdb.org/t/p/w185{c['profile_path']}" if c.get("profile_path") else "",
        }
        for c in ((details or {}).get("credits", {}).get("cast") or [])[:15]
    ]


def show_movie_genre_titles(params):
    genre_id = params.get("genre_id", "")
    genre_name = params.get("genre_name", "Genre")
    xbmcplugin.setPluginCategory(HANDLE, f"{genre_name} Movies")
    xbmcplugin.setContent(HANDLE, "movies")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)

    addon = xbmcaddon.Addon()
    tmdb = TmdbApi(addon)
    if not tmdb.is_configured() or not genre_id:
        add_item("TMDB isn't configured — set a TMDB API key in add-on settings.")
        end_dir()
        return

    known_ids = SimklApi(addon).known_tmdb_ids("movie")
    show_posters = addon.getSettingBool("show_posters")
    results = _discover_top_rated(tmdb, "movie", int(genre_id), exclude_tmdb_ids=known_ids)
    _safe_tmdb(lambda: tmdb.prefetch_details("movie", [r.get("id") for r in results]), "prefetch movie details")
    for r in results:
        title = r.get("title") or r.get("original_title") or "Unknown title"
        year = (r.get("release_date") or "")[:4]
        tmdb_id = r.get("id")
        overview = r.get("overview") or ""
        vote_average = r.get("vote_average") or 0.0
        vote_count = r.get("vote_count") or 0

        label = f"{title} ({year})" if year else title

        art = None
        if show_posters:
            purl = tmdb_poster_url(r.get("poster_path"))
            if purl:
                art = {"thumb": purl, "poster": purl, "icon": purl}

        info = {"title": title, "genre": genre_name}
        if year:
            info["year"] = year
        plot = _plot_with_rating_header(overview, year, vote_average, vote_count, source="TMDB")
        if plot:
            info["plot"] = plot
        if vote_average:
            info["rating"] = float(vote_average)
        if vote_count:
            info["votes"] = str(vote_count)
        info["trailer"] = build_url(action="play_trailer", title=title, tmdb_id=str(tmdb_id), kind="movie")

        url = _movie_play_url(title, "", tmdb_id, year)

        ctx = [
            ("Movie Information", "Action(Info)"),
            *_movie_play_menu(title, "", tmdb_id, year),
            ("Watch Trailer", f"RunPlugin({build_url(action='play_trailer', title=title, tmdb_id=str(tmdb_id), kind='movie')})"),
            ("Add to Watchlist", f"RunPlugin({build_url(action='recommended_watchlist', kind='movie', tmdb_id=str(tmdb_id), title=title)})"),
            ("Mark as Watched", f"RunPlugin({build_url(action='recommended_watched', kind='movie', tmdb_id=str(tmdb_id), title=title)})"),
            ("Remove Movie", f"RunPlugin({build_url(action='recommended_remove', kind='movie', tmdb_id=str(tmdb_id), title=title)})"),
        ]

        details = tmdb.movie_details_if_cached(tmdb_id) if tmdb_id else None
        add_item(label, url=url, info=info, art=art, is_folder=False, context_menu=ctx, cast=_tmdb_cast(details) or None)

    end_dir()


def show_tv_genre_titles(params):
    genre_id = params.get("genre_id", "")
    genre_name = params.get("genre_name", "Genre")
    xbmcplugin.setPluginCategory(HANDLE, f"{genre_name} Series")
    xbmcplugin.setContent(HANDLE, "tvshows")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)

    addon = xbmcaddon.Addon()
    tmdb = TmdbApi(addon)
    if not tmdb.is_configured() or not genre_id:
        add_item("TMDB isn't configured — set a TMDB API key in add-on settings.")
        end_dir()
        return

    known_ids = SimklApi(addon).known_tmdb_ids("show")
    show_posters = addon.getSettingBool("show_posters")
    results = _discover_top_rated(tmdb, "tv", int(genre_id), exclude_tmdb_ids=known_ids)
    _safe_tmdb(lambda: tmdb.prefetch_details("tv", [r.get("id") for r in results]), "prefetch tv details")
    for r in results:
        title = r.get("name") or r.get("original_name") or "Unknown title"
        year = (r.get("first_air_date") or "")[:4]
        tmdb_id = r.get("id")
        overview = r.get("overview") or ""
        vote_average = r.get("vote_average") or 0.0
        vote_count = r.get("vote_count") or 0

        label = f"{title} ({year})" if year else title

        art = None
        if show_posters:
            purl = tmdb_poster_url(r.get("poster_path"))
            if purl:
                art = {"thumb": purl, "poster": purl, "icon": purl}

        info = {"title": title, "genre": genre_name}
        if year:
            info["year"] = year
        plot = _plot_with_rating_header(overview, year, vote_average, vote_count, source="TMDB")
        if plot:
            info["plot"] = plot
        if vote_average:
            info["rating"] = float(vote_average)
        if vote_count:
            info["votes"] = str(vote_count)
        info["trailer"] = build_url(action="play_trailer", title=title, tmdb_id=str(tmdb_id), kind="show")

        url = build_url(
            action="show_seasons",
            title=title, imdb="", tmdb=str(tmdb_id), year=year, next="",
            simkl_poster="", simkl_id="",
        )

        ctx = [
            ("Show Information", "Action(Info)"),
            ("Watch Trailer", f"RunPlugin({build_url(action='play_trailer', title=title, tmdb_id=str(tmdb_id), kind='show')})"),
            ("Add to Watchlist", f"RunPlugin({build_url(action='recommended_watchlist', kind='show', tmdb_id=str(tmdb_id), title=title)})"),
            ("Mark Show as Watched", f"RunPlugin({build_url(action='recommended_watched', kind='show', tmdb_id=str(tmdb_id), title=title)})"),
            ("Remove Show", f"RunPlugin({build_url(action='recommended_remove', kind='show', tmdb_id=str(tmdb_id), title=title)})"),
        ]

        details = tmdb.tv_details_if_cached(tmdb_id) if tmdb_id else None
        add_item(label, url=url, info=info, art=art, is_folder=True, context_menu=ctx, cast=_tmdb_cast(details) or None)

    end_dir()


def _add_recommended_item(item, kind):
    """Shared renderer for show_recommended_shows()/show_recommended_movies().
    Normal click opens the same target screen a Search selection would
    (show_seasons for shows, show_movie for movies - see search_series()/
    search_movies()), rather than a custom season-1 shortcut. Right-click
    offers Watch Trailer (same as New Episodes) and Remove, which marks the
    item 'dropped' in SIMKL and drops it from the cached list immediately."""
    title = item.get("title") or "Unknown title"
    year = item.get("year") or ""
    imdb_id = item.get("imdb_id") or ""
    tmdb_id = item.get("tmdb_id") or ""
    simkl_id = item.get("simkl_id") or ""
    poster_path = item.get("poster")
    overview = item.get("overview") or ""
    rating = item.get("rating") or 0.0
    votes = item.get("votes") or 0
    because = item.get("because") or []

    label = f"{title} ({year})" if year else title

    addon = xbmcaddon.Addon()
    art = None
    show_posters = addon.getSettingBool("show_posters")
    if show_posters:
        purl = simkl_poster_url(poster_path)
        if purl:
            art = {"thumb": purl, "poster": purl, "icon": purl}

    # Cast/genre/runtime come pre-baked from recommendations.build()'s own TMDB
    # lookup (which already fetches these per item to apply the English-only
    # filter) - NOT fetched live here. A live per-item fetch at render time is
    # what caused this screen to time out once MAX_ITEMS got large enough that
    # most items were still cold (confirmed: dozens of sequential uncached TMDB
    # calls, Kodi's GetDirectory gave up while the script kept running).
    cast = item.get("cast") or []
    genres = item.get("genres") or []
    runtime = item.get("runtime") if kind == "movie" else None

    plot = overview
    if because:
        hint = f"Because you watched: {', '.join(because)}"
        plot = (plot + "\n\n" if plot else "") + hint
    plot = _plot_with_rating_header(plot, year, rating, votes, source="SIMKL")

    info = {"title": title}
    if plot:
        info["plot"] = plot
    if rating:
        info["rating"] = float(rating)
    if votes:
        info["votes"] = str(votes)
    if runtime:
        info["duration"] = int(runtime) * 60
    if genres:
        info["genre"] = ", ".join(genres)
    if simkl_id:
        info["trailer"] = build_url(action="play_trailer", title=title, simkl_id=simkl_id, kind=kind)

    if kind == "show":
        url = build_url(
            action="show_seasons",
            title=title, imdb=imdb_id, tmdb=tmdb_id, year=year, next="",
            simkl_poster=poster_path or "", simkl_id=simkl_id,
        )
    else:
        url = _movie_play_url(title, imdb_id, tmdb_id, year)

    ctx = []
    ctx.append((f"{'Movie' if kind == 'movie' else 'Show'} Information", "Action(Info)"))
    ctx.append(("Watch Trailer", f"RunPlugin({build_url(action='play_trailer', title=title, simkl_id=simkl_id, kind=kind)})"))
    ctx.append(("Add to Watchlist", f"RunPlugin({build_url(action='recommended_watchlist', kind=kind, simkl_id=simkl_id, title=title)})"))
    ctx.append(("Mark as Watched", f"RunPlugin({build_url(action='recommended_watched', kind=kind, simkl_id=simkl_id, title=title)})"))
    ctx.append((f"Remove {'Movie' if kind == 'movie' else 'Show'}", f"RunPlugin({build_url(action='recommended_remove', kind=kind, simkl_id=simkl_id, title=title)})"))

    if kind == "movie":
        ctx.extend(_movie_play_menu(title, imdb_id, tmdb_id, year))
    add_item(label, url=url, info=info, art=art, is_folder=(kind == "show"), context_menu=ctx, cast=cast or None)


def show_recommended_shows():
    xbmcplugin.setPluginCategory(HANDLE, "Recommended Shows")
    xbmcplugin.setContent(HANDLE, "tvshows")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    data = recommendations.load()
    shows = (data or {}).get("shows") or []
    if not shows:
        add_item("No recommendations yet — run Tools -> 'WhatsUpNext: Warm episode cache now' to generate them.")
        end_dir()
        return
    for item in shows:
        _add_recommended_item(item, "show")
    end_dir()


def show_recommended_movies():
    xbmcplugin.setPluginCategory(HANDLE, "Recommended Movies")
    xbmcplugin.setContent(HANDLE, "movies")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    data = recommendations.load()
    movies = (data or {}).get("movies") or []
    if not movies:
        add_item("No recommendations yet — run Tools -> 'WhatsUpNext: Warm episode cache now' to generate them.")
        end_dir()
        return
    for item in movies:
        _add_recommended_item(item, "movie")
    end_dir()


def _resolve_simkl_id(params, api):
    """Returns an int SIMKL id for a context-menu action. Uses params['simkl_id']
    when the item already carries one (Recommended items do); otherwise resolves
    it on the spot from params['tmdb_id'] + params['kind'] via
    SimklApi.find_id_by_tmdb() (Genre-browse items, which come straight from
    TMDB, only have a tmdb_id until an action like this needs a SIMKL one).
    Returns None if neither is available or the lookup finds nothing."""
    raw = params.get("simkl_id", "")
    if raw:
        try:
            return int(raw)
        except (TypeError, ValueError):
            pass
    tmdb_id = params.get("tmdb_id", "")
    if not tmdb_id:
        return None
    try:
        return api.find_id_by_tmdb(params.get("kind", "show"), int(tmdb_id))
    except (TypeError, ValueError):
        return None


def recommended_remove(params):
    """Context-menu 'Remove' on a Recommended or Genre item: marks it 'dropped'
    in SIMKL (so it won't be suggested again - see recommendations.build()'s
    dropped-list exclusion) and drops it from the cached Recommended list if it
    was in one (a no-op for Genre items, which aren't cached locally)."""
    kind = params.get("kind", "show")
    title = params.get("title", "this title")

    addon = xbmcaddon.Addon()
    api = SimklApi(addon)
    if not api.is_authorized():
        xbmcgui.Dialog().notification("WhatsOnStreamer", "Not authorized with SIMKL", xbmcgui.NOTIFICATION_ERROR)
        return

    simkl_id = _resolve_simkl_id(params, api)
    if not simkl_id:
        xbmcgui.Dialog().notification("WhatsOnStreamer", "Couldn't match this title in SIMKL", xbmcgui.NOTIFICATION_ERROR)
        return

    try:
        api.add_to_dropped(kind, simkl_id)
    except Exception as e:
        xbmc.log(f"[WhatsOnStreamer] add_to_dropped failed for {title}: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("WhatsOnStreamer", "Failed to mark as dropped in SIMKL", xbmcgui.NOTIFICATION_ERROR)
        return

    recommendations.remove_item(kind, simkl_id)
    xbmcgui.Dialog().notification("WhatsOnStreamer", f"Dropped: {title}", xbmcgui.NOTIFICATION_INFO, 1500)


def recommended_watched(params):
    """Context-menu 'Mark as Watched': POSTs real watch history via
    SimklApi.mark_watched() (/sync/history - for a show this marks every
    aired episode watched), so it counts toward future recommendation seeding
    rather than being excluded like a drop. Removes it from the cached
    Recommended list immediately, same as recommended_remove()."""
    kind = params.get("kind", "show")
    title = params.get("title", "this title")

    addon = xbmcaddon.Addon()
    api = SimklApi(addon)
    if not api.is_authorized():
        xbmcgui.Dialog().notification("WhatsOnStreamer", "Not authorized with SIMKL", xbmcgui.NOTIFICATION_ERROR)
        return

    simkl_id = _resolve_simkl_id(params, api)
    if not simkl_id:
        xbmcgui.Dialog().notification("WhatsOnStreamer", "Couldn't match this title in SIMKL", xbmcgui.NOTIFICATION_ERROR)
        return

    try:
        api.mark_watched(kind, simkl_id)
    except Exception as e:
        xbmc.log(f"[WhatsOnStreamer] mark_watched failed for {title}: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("WhatsOnStreamer", "Failed to mark as watched in SIMKL", xbmcgui.NOTIFICATION_ERROR)
        return

    recommendations.remove_item(kind, simkl_id)
    xbmcgui.Dialog().notification("WhatsOnStreamer", f"Marked watched: {title}", xbmcgui.NOTIFICATION_INFO, 1500)


def mark_episode_watched(params):
    """Context-menu 'Mark Episode as Watched' inside an episode list - marks
    just that one episode via SimklApi.mark_episode_watched(), not the whole
    show. Refreshes the container so the playcount tick shows up immediately
    (mark_episode_watched() clears the 2-min watching-status cache too)."""
    title = params.get("title", "this title")
    try:
        simkl_id = int(params.get("simkl_id", ""))
        season = int(params.get("season", ""))
        episode = int(params.get("episode", ""))
    except (TypeError, ValueError):
        xbmcgui.Dialog().notification("WhatsOnStreamer", "Missing SIMKL id/season/episode", xbmcgui.NOTIFICATION_ERROR)
        return

    addon = xbmcaddon.Addon()
    api = SimklApi(addon)
    if not api.is_authorized():
        xbmcgui.Dialog().notification("WhatsOnStreamer", "Not authorized with SIMKL", xbmcgui.NOTIFICATION_ERROR)
        return

    try:
        api.mark_episode_watched(simkl_id, season, episode)
    except Exception as e:
        xbmc.log(f"[WhatsOnStreamer] mark_episode_watched failed for {title} S{season:02d}E{episode:02d}: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("WhatsOnStreamer", "Failed to mark episode as watched in SIMKL", xbmcgui.NOTIFICATION_ERROR)
        return

    xbmcgui.Dialog().notification("WhatsOnStreamer", f"Marked watched: {title} S{season:02d}E{episode:02d}", xbmcgui.NOTIFICATION_INFO, 1500)


def mark_season_watched(params):
    """Context-menu 'Mark Season as Watched' - marks every episode number in
    `episodes` (comma-separated, built from the same episode list the screen
    already rendered) via SimklApi.mark_season_watched()."""
    title = params.get("title", "this title")
    try:
        simkl_id = int(params.get("simkl_id", ""))
        season = int(params.get("season", ""))
        episode_numbers = [int(e) for e in params.get("episodes", "").split(",") if e]
    except (TypeError, ValueError):
        xbmcgui.Dialog().notification("WhatsOnStreamer", "Missing SIMKL id/season/episodes", xbmcgui.NOTIFICATION_ERROR)
        return
    if not episode_numbers:
        xbmcgui.Dialog().notification("WhatsOnStreamer", "No episodes to mark", xbmcgui.NOTIFICATION_WARNING)
        return

    addon = xbmcaddon.Addon()
    api = SimklApi(addon)
    if not api.is_authorized():
        xbmcgui.Dialog().notification("WhatsOnStreamer", "Not authorized with SIMKL", xbmcgui.NOTIFICATION_ERROR)
        return

    try:
        api.mark_season_watched(simkl_id, season, episode_numbers)
    except Exception as e:
        xbmc.log(f"[WhatsOnStreamer] mark_season_watched failed for {title} S{season:02d}: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("WhatsOnStreamer", "Failed to mark season as watched in SIMKL", xbmcgui.NOTIFICATION_ERROR)
        return

    xbmcgui.Dialog().notification("WhatsOnStreamer", f"Marked watched: {title} Season {season}", xbmcgui.NOTIFICATION_INFO, 1500)


def recommended_watchlist(params):
    """Context-menu 'Add to Watchlist' on a Recommended item: shows go straight to
    'watching' in SIMKL (SimklApi.add_to_watchlist), movies go to 'plantowatch' -
    SIMKL doesn't have a 'watching' status for movies. Drops it from the cached
    Recommended list immediately, same as recommended_remove()."""
    kind = params.get("kind", "show")
    title = params.get("title", "this title")

    addon = xbmcaddon.Addon()
    api = SimklApi(addon)
    if not api.is_authorized():
        xbmcgui.Dialog().notification("WhatsOnStreamer", "Not authorized with SIMKL", xbmcgui.NOTIFICATION_ERROR)
        return

    simkl_id = _resolve_simkl_id(params, api)
    if not simkl_id:
        xbmcgui.Dialog().notification("WhatsOnStreamer", "Couldn't match this title in SIMKL", xbmcgui.NOTIFICATION_ERROR)
        return

    try:
        api.add_to_watchlist(kind, simkl_id)
    except Exception as e:
        xbmc.log(f"[WhatsOnStreamer] add_to_watchlist failed for {title}: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("WhatsOnStreamer", "Failed to add to watchlist in SIMKL", xbmcgui.NOTIFICATION_ERROR)
        return

    recommendations.remove_item(kind, simkl_id)
    status_label = "Watching" if kind == "show" else "Watchlist"
    xbmcgui.Dialog().notification("WhatsOnStreamer", f"Added to {status_label}: {title}", xbmcgui.NOTIFICATION_INFO, 1500)


def show_search_menu():
    xbmcplugin.setPluginCategory(HANDLE, "Search")
    add_item("Series", url=build_url(action="search_series"), art={"icon": f"{MEDIA_PATH}/new.png", "thumb": f"{MEDIA_PATH}/new.png"})
    add_item("Movies", url=build_url(action="search_movies"), art={"icon": f"{MEDIA_PATH}/movies.png", "thumb": f"{MEDIA_PATH}/movies.png"})
    end_dir()


def _simkl_search_and_open(noun, dialog_title, search_fn, target_action, extra_url_params=None):
    """Non-folder action: prompt + select, then Container.Update into our own
    listing (show_seasons for series, show_movie for movies) — the same
    screen used for scrobbled/watching items, so the IPTV / local / AllDebrid
    / Homelander choice is preserved. See livetv.list_root's Search item for
    why this must stay a plain script invocation rather than a folder item —
    a folder item racing its own in-flight GetDirectory against this dialog
    is a silent no-op.
    """
    addon = xbmcaddon.Addon()
    api = SimklApi(addon)

    if not api.is_configured():
        xbmcgui.Dialog().notification(
            dialog_title,
            "SIMKL Client ID required. Add it in Settings.",
            xbmcgui.NOTIFICATION_WARNING,
        )
        return

    term = xbmcgui.Dialog().input(dialog_title, type=xbmcgui.INPUT_ALPHANUM)
    if not term or not term.strip():
        return

    try:
        items = search_fn(api, term.strip())
    except Exception as e:
        xbmc.log(f"[WhatsOnStreamer] SIMKL search ({noun}) failed: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(dialog_title, "SIMKL search failed", xbmcgui.NOTIFICATION_ERROR)
        return

    if not items:
        xbmcgui.Dialog().notification(dialog_title, "No results found", xbmcgui.NOTIFICATION_INFO)
        return

    # Build selection list (cap at 10 for usability)
    items = items[:10]
    labels = []
    for r in items:
        title = r.get("title") or "Unknown"
        year = r.get("year") or ""
        labels.append(f"{title} ({year})" if year else title)

    choice = xbmcgui.Dialog().select(f"Select {noun}", labels)
    if choice < 0:
        return

    chosen = items[choice]
    ids = chosen.get("ids") or {}
    title = chosen.get("title") or term.strip()
    year = str(chosen.get("year") or "")
    imdb_id = ids.get("imdb") or ""
    tmdb_id = ids.get("tmdb") or ""
    # SIMKL's /search/tv and /search/movie responses key this "simkl_id", not "simkl"
    # like /tv/{id}, /movies/{id}, and the sync/all-items endpoints do - a genuine
    # inconsistency in SIMKL's own API. Check both so search-originated items still
    # get a working simkl_id (needed for the season/movie screens' context menus).
    simkl_id = ids.get("simkl_id") or ids.get("simkl") or ""
    poster_path = chosen.get("poster") or ""

    url = build_url(
        action=target_action,
        title=title, imdb=imdb_id, tmdb=str(tmdb_id), year=year,
        simkl_poster=poster_path, simkl_id=str(simkl_id),
        **(extra_url_params or {}),
    )
    xbmc.sleep(500)
    xbmc.executebuiltin(f'Container.Update({url})')


def search_series():
    _simkl_search_and_open(
        "Series", "Search Series",
        lambda api, term: api.search_shows(term),
        "show_seasons", extra_url_params={"next": ""},
    )


def search_movies():
    _simkl_search_and_open(
        "Movie", "Search Movies",
        lambda api, term: api.search_movies(term),
        "show_movie",
    )


def show_help():
    xbmcplugin.setPluginCategory(HANDLE, "Settings / Help")
    add_item("SIMKL authorization moved to the root Tools menu.")
    add_item("Tip: Add TMDB API key in Settings to show episode air dates / countdown.")
    add_item("Debug: Enable 'Debug logging' to log raw SIMKL/TMDB responses.")
    end_dir()


def show_auth():
    addon = xbmcaddon.Addon()
    api = SimklApi(addon)

    if not api.is_configured():
        xbmcgui.Dialog().ok(
            "SIMKL • Watching",
            "No SIMKL Client ID found.\n\n"
            "Go to the add-on Settings and paste your SIMKL Client ID (API Key)."
        )
        show_help()
        return

    try:
        pin = api.request_pin()
    except Exception as e:
        xbmc.log(f"[WhatsOnStreamer] PIN request failed: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("SIMKL", "PIN request failed", xbmcgui.NOTIFICATION_ERROR)
        show_whatsupnext_menu()
        return

    user_code = pin.get("user_code")
    verify_url = pin.get("verification_url") or "https://simkl.com/pin/"
    expires_in = int(pin.get("expires_in", 900))
    interval = int(pin.get("interval", 5))

    if not user_code:
        xbmcgui.Dialog().notification("SIMKL", "PIN response missing user_code", xbmcgui.NOTIFICATION_ERROR)
        show_whatsupnext_menu()
        return

    xbmcgui.Dialog().ok(
        "SIMKL Authorization",
        f"On your phone/PC visit:\n{verify_url}\n\n"
        f"Enter this code:\n\n{user_code}\n\n"
        "Approve access, then return to Kodi."
    )

    dp = xbmcgui.DialogProgress()
    dp.create("SIMKL Authorization", "Waiting for approval…")

    def progress_cb(remaining):
        percent = int((expires_in - remaining) * 100 / expires_in)
        percent = max(0, min(100, percent))
        dp.update(percent, f"Code: {user_code}\nTime left: {remaining}s")

    token = None
    cancelled = False
    try:
        token = api.poll_pin(user_code, interval, expires_in, progress_cb=progress_cb, cancel_fn=dp.iscanceled)
        cancelled = dp.iscanceled()
    finally:
        dp.close()

    if token:
        api.save_token(token)
        xbmcgui.Dialog().notification("SIMKL", "Authorized successfully!", xbmcgui.NOTIFICATION_INFO)
    elif cancelled:
        xbmcgui.Dialog().notification("SIMKL", "Authorization cancelled", xbmcgui.NOTIFICATION_WARNING)
    else:
        xbmcgui.Dialog().notification("SIMKL", "Authorization timed out", xbmcgui.NOTIFICATION_ERROR)

    show_whatsupnext_menu()


# --------------------------
# Aired-episode screen (SIMKL extended=full)
# --------------------------
def _parse_date(d):
    if not d:
        return None
    try:
        if len(d) == 10:
            return datetime.strptime(d, "%Y-%m-%d").date()
        if d.endswith("Z"):
            return datetime.strptime(d, "%Y-%m-%dT%H:%M:%SZ").date()
        return datetime.strptime(d[:10], "%Y-%m-%d").date()
    except Exception:
        return None


def _today_utc():
    return datetime.now(timezone.utc).date()


def _flatten_episodes(show_json):
    """
    Turns show['seasons'][...]['episodes'][...] into a flat list.
    """
    out = []
    seasons = show_json.get("seasons") or []
    for s in seasons:
        s_num = s.get("number")
        eps = s.get("episodes") or []
        for e in eps:
            e_num = e.get("number")
            title = e.get("title") or f"Episode {e_num}"
            air = e.get("aired") or e.get("first_aired") or e.get("air_date") or e.get("date")
            out.append({
                "season": s_num,
                "episode": e_num,
                "title": title,
                "air_raw": air
            })
    return out


def show_show_info(action):
    addon = xbmcaddon.Addon()
    api = SimklApi(addon)

    try:
        simkl_id = int(action.split("_", 1)[1])
    except Exception:
        xbmcgui.Dialog().notification("SIMKL", "Invalid show id", xbmcgui.NOTIFICATION_ERROR)
        show_new_episodes()
        return

    try:
        show = api.get_show_details_full(simkl_id)
    except Exception as e:
        xbmc.log(f"[WhatsOnStreamer] show details failed: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("SIMKL", "Failed to load show details", xbmcgui.NOTIFICATION_ERROR)
        show_new_episodes()
        return

    title = show.get("title") or f"Show {simkl_id}"
    xbmcplugin.setPluginCategory(HANDLE, f"{title} — Aired Episodes")

    episodes = _flatten_episodes(show)
    today = _today_utc()
    aired = []

    for e in episodes:
        d = _parse_date(e.get("air_raw"))
        if d and d <= today:
            aired.append((d, e))

    aired.sort(key=lambda x: (x[0], x[1]["season"] or 0, x[1]["episode"] or 0))

    if not aired:
        add_item("No aired episodes found (or data missing).")
        end_dir()
        return

    for d, e in aired:
        s = e["season"] or 0
        n = e["episode"] or 0
        label = f"S{s:02d}E{n:02d} — {e['title']} ({d.isoformat()})"
        add_item(label, info={"title": e["title"]})

    end_dir()


# --------------------------
# Season browser
# --------------------------
def show_seasons(params):
    title = params.get("title", "")
    imdb_id = params.get("imdb", "")
    tmdb_id = params.get("tmdb", "")
    year = params.get("year", "")
    next_ep = params.get("next", "")
    simkl_poster = params.get("simkl_poster", "")
    simkl_id = params.get("simkl_id", "")

    se = parse_sxxexx(next_ep)
    current_season = se[0] if se else 1

    xbmcplugin.setPluginCategory(HANDLE, f"{title} — Seasons")
    addon = xbmcaddon.Addon()

    seasons = []  # list of (season_num, name, ep_count, poster_path)
    show_poster_url = simkl_poster_url(simkl_poster) if simkl_poster else None

    if tmdb_id:
        try:
            tmdb = TmdbApi(addon)
            if tmdb.is_configured():
                tv = tmdb.tv_details(int(tmdb_id))
                for s in tv.get("seasons", []) or []:
                    sn = s.get("season_number", 0)
                    if sn == 0:
                        continue
                    seasons.append((
                        sn,
                        s.get("name") or f"Season {sn}",
                        s.get("episode_count") or 0,
                        s.get("poster_path"),
                    ))
        except Exception as e:
            xbmc.log(f"[WhatsOnStreamer] TMDB tv_details failed: {e}", xbmc.LOGERROR)

    if not seasons:
        seasons = [(n, f"Season {n}", 0, None) for n in range(1, current_season + 1)]

    for sn, name, ep_count, poster_path in seasons:
        label = f"► {name}" if sn == current_season else name
        if ep_count:
            label += f"  ({ep_count} eps)"

        if poster_path:
            purl = tmdb_poster_url(poster_path)
            art = {"thumb": purl, "poster": purl, "icon": purl}
        elif show_poster_url:
            art = {"thumb": show_poster_url, "poster": show_poster_url, "icon": show_poster_url}
        else:
            art = None

        url = build_url(
            action="show_season_episodes",
            title=title, imdb=imdb_id, tmdb=tmdb_id, year=year,
            next=next_ep, season_num=sn,
            simkl_poster=simkl_poster, simkl_id=simkl_id,
        )

        ctx = None
        if simkl_id:
            season_eps = ",".join(str(n) for n in range(1, (ep_count or 1) + 1))
            ctx = [
                ("Watch Trailer", f"RunPlugin({build_url(action='play_trailer', title=title, simkl_id=simkl_id, kind='show')})"),
                ("Add to Watchlist", f"RunPlugin({build_url(action='recommended_watchlist', kind='show', simkl_id=simkl_id, title=title)})"),
                ("Mark Season as Watched", f"RunPlugin({build_url(action='mark_season_watched', simkl_id=simkl_id, season=sn, episodes=season_eps, title=title)})"),
                ("Mark Show as Watched", f"RunPlugin({build_url(action='recommended_watched', kind='show', simkl_id=simkl_id, title=title)})"),
            ]

        add_item(label, url=url, art=art, is_folder=True, context_menu=ctx)

    end_dir()


# --------------------------
# Season episode list
# --------------------------
def show_season_episodes(params):
    title = params.get("title", "")
    imdb_id = params.get("imdb", "")
    tmdb_id = params.get("tmdb", "")
    year = params.get("year", "")
    next_ep = params.get("next", "")
    simkl_poster = params.get("simkl_poster", "")
    simkl_id = params.get("simkl_id", "")

    # season_num overrides the season from next_ep (used when browsing other seasons)
    se = parse_sxxexx(next_ep)
    next_ep_num = se[1] if se else None
    next_season = se[0] if se else 1

    try:
        season = int(params["season_num"])
    except (KeyError, ValueError, TypeError):
        season = next_season

    if not season:
        open_homelander(params)
        return

    xbmcplugin.setPluginCategory(HANDLE, f"{title} — Season {season}")
    xbmcplugin.setContent(HANDLE, "episodes")
    addon = xbmcaddon.Addon()

    episodes = []  # list of dicts; see TMDB extraction block below
    show_poster_url = simkl_poster_url(simkl_poster) if simkl_poster else None

    if tmdb_id:
        try:
            tmdb = TmdbApi(addon)
            if tmdb.is_configured():
                season_data = tmdb.tv_season(int(tmdb_id), season)
                for ep in season_data.get("episodes", []) or []:
                    ep_num = ep.get("episode_number")
                    if not ep_num:
                        continue
                    crew = ep.get("crew") or []
                    guest_stars = ep.get("guest_stars") or []
                    episodes.append({
                        "ep_num": int(ep_num),
                        "ep_title": ep.get("name") or f"Episode {ep_num}",
                        "air_date": ep.get("air_date") or "",
                        "still_path": ep.get("still_path"),
                        "overview": ep.get("overview") or "",
                        "vote_average": ep.get("vote_average") or 0.0,
                        "vote_count": ep.get("vote_count") or 0,
                        "runtime": ep.get("runtime"),
                        "directors": [c["name"] for c in crew if c.get("job") == "Director"],
                        "writers": [c["name"] for c in crew if c.get("job") in ("Writer", "Screenplay", "Story", "Teleplay")],
                        "cast": [
                            {
                                "name": g["name"],
                                "role": g.get("character") or "",
                                "thumbnail": f"https://image.tmdb.org/t/p/w185{g['profile_path']}" if g.get("profile_path") else "",
                            }
                            for g in guest_stars
                        ],
                    })
        except Exception as e:
            xbmc.log(f"[WhatsOnStreamer] TMDB season fetch failed: {e}", xbmc.LOGERROR)

    if not episodes:
        episodes = [
            {"ep_num": n, "ep_title": f"Episode {n}", "air_date": "", "still_path": None,
             "overview": "", "vote_average": 0.0, "vote_count": 0, "runtime": None,
             "directors": [], "writers": [], "cast": []}
            for n in range(1, 27)
        ]

    all_seasons_url = build_url(
        action="show_seasons",
        title=title, imdb=imdb_id, tmdb=tmdb_id, year=year,
        next=next_ep, simkl_poster=simkl_poster, simkl_id=simkl_id,
    )
    art_fallback = {"thumb": show_poster_url, "icon": show_poster_url} if show_poster_url else None
    add_item("« All Seasons", url=all_seasons_url, art=art_fallback, is_folder=True)

    # Fetch AllDebrid availability for the whole season in one pass
    ad_available = set()
    try:
        ad_api = AllDebridApi()
        if ad_api.is_configured():
            ad_available = ad_api.get_available_episodes(title, season)
    except Exception as e:
        xbmc.log(f"[WhatsOnStreamer] AllDebrid availability check failed: {e}", xbmc.LOGERROR)

    # Fetch local file availability — dict of {ep_num: file_path}
    lf_available = {}
    try:
        lf_api = LocalMediaApi()
        if lf_api.is_configured():
            lf_available = lf_api.get_available_episodes_with_paths(title, season)
    except Exception as e:
        xbmc.log(f"[WhatsOnStreamer] Local media availability check failed: {e}", xbmc.LOGERROR)

    # Fetch IPTV (Xtream series) availability for the whole season in one pass
    iptv_available = set()
    try:
        iptv_api = IptvApi()
        if iptv_api.is_configured():
            iptv_available = iptv_api.get_available_episodes(title, season)
    except Exception as e:
        xbmc.log(f"[WhatsOnStreamer] IPTV availability check failed: {e}", xbmc.LOGERROR)

    # Fetch SIMKL watched status for this season, for the native playcount tick
    watched_available = set()
    show_completed = False
    if simkl_id:
        try:
            simkl_api = SimklApi(addon)
            if simkl_api.is_authorized():
                show_completed = simkl_api.is_show_completed(int(simkl_id))
                if not show_completed:
                    watched_available = simkl_api.get_watched_episodes(int(simkl_id), season)
        except Exception as e:
            xbmc.log(f"[WhatsOnStreamer] SIMKL watched-status check failed: {e}", xbmc.LOGERROR)

    today = date.today()

    season_eps = ",".join(str(ep["ep_num"]) for ep in episodes)

    for ep in episodes:
        ep_num    = ep["ep_num"]
        ep_title  = ep["ep_title"]
        air_date  = ep["air_date"]
        still_path = ep["still_path"]
        overview   = ep["overview"]
        vote_average = ep["vote_average"]
        vote_count   = ep["vote_count"]
        runtime      = ep["runtime"]
        directors    = ep["directors"]
        writers      = ep["writers"]
        ep_cast      = ep["cast"]

        code = f"S{season:02d}E{ep_num:02d}"

        label = f"{code} — {ep_title}"
        if air_date:
            label += f"  ({air_date})"
        if season == next_season and ep_num == next_ep_num:
            label = f"► {label}"
        if air_date:
            d = _parse_ymd_date(air_date)
            if d and d > today:
                label += "  [upcoming]"

        if still_path:
            surl = f"https://image.tmdb.org/t/p/w300{still_path}"
            art = {"thumb": surl, "icon": surl}
        elif show_poster_url:
            art = {"thumb": show_poster_url, "icon": show_poster_url}
        else:
            art = None

        hl_url = build_url(
            action="open_homelander",
            title=title, imdb=imdb_id, tmdb=tmdb_id, year=year,
            next=code, ep_title=ep_title, air_date=air_date
        )

        # Default click priority: local file -> IPTV -> Homelander (catch-all).
        # AllDebrid stays "Play via AllDebrid"-only: once Homelander is handed off
        # it can't report failure back to us, so nothing can fall through past it.
        local_path = lf_available.get(ep_num)
        if local_path:
            default_url = local_path
            is_playable = True
        elif ep_num in iptv_available:
            default_url = build_url(action="play_iptv", title=title, season=season, episode=ep_num, imdb=imdb_id, tmdb=tmdb_id)
            is_playable = False
        else:
            default_url = hl_url
            is_playable = False

        if ep_num in ad_available:
            label += "  [COLOR lime]● AD[/COLOR]"
        if local_path:
            label += "  [COLOR dodgerblue]● LF[/COLOR]"
        if ep_num in iptv_available:
            label += "  [COLOR orange]● IPTV[/COLOR]"

        ctx = [
            ("Play via AllDebrid", f"RunPlugin({build_url(action='play_alldebrid', title=title, season=season, episode=ep_num, imdb=imdb_id, tmdb=tmdb_id)})"),
        ]
        if local_path:
            ctx.append(("Play local file", f"RunPlugin({build_url(action='play_local', title=title, season=season, episode=ep_num)})"))
        ctx.append(("Play via Homelander", f"RunPlugin({hl_url})"))
        ctx.append(("Play via IPTV", f"RunPlugin({build_url(action='play_iptv', title=title, season=season, episode=ep_num, imdb=imdb_id, tmdb=tmdb_id)})"))
        if simkl_id:
            ctx.append(("Watch Trailer", f"RunPlugin({build_url(action='play_trailer', title=title, simkl_id=simkl_id)})"))
            ctx.append(("Mark Episode as Watched", f"RunPlugin({build_url(action='mark_episode_watched', simkl_id=simkl_id, season=season, episode=ep_num, title=title)})"))
            ctx.append(("Mark Season as Watched", f"RunPlugin({build_url(action='mark_season_watched', simkl_id=simkl_id, season=season, episodes=season_eps, title=title)})"))
            ctx.append(("Mark Show as Watched", f"RunPlugin({build_url(action='recommended_watched', kind='show', simkl_id=simkl_id, title=title)})"))

        info = {
            "title": ep_title,
            "tvshowtitle": title,
            "episode": ep_num,
            "season": season,
        }
        if overview:
            info["plot"] = overview
        if vote_average:
            info["rating"] = float(vote_average)
        if vote_count:
            info["votes"] = str(vote_count)
        if air_date:
            info["premiered"] = air_date
        if runtime:
            info["duration"] = int(runtime) * 60
        if directors:
            info["director"] = ", ".join(directors)
        if writers:
            info["writer"] = ", ".join(writers)
        if show_completed or ep_num in watched_available:
            info["playcount"] = 1

        add_item(
            label, url=default_url,
            info=info,
            art=art, context_menu=ctx,
            is_folder=False,
            cast=ep_cast or None,
            is_playable=is_playable,
        )

    end_dir()


# --------------------------
# Single movie screen — the movie equivalent of show_season_episodes: one
# item, but with the same local/AllDebrid/IPTV/Homelander choice.
# --------------------------
def show_movie_item(params):
    title = params.get("title", "")
    imdb_id = params.get("imdb", "")
    tmdb_id = params.get("tmdb", "")
    year = params.get("year", "")
    simkl_poster = params.get("simkl_poster", "")
    simkl_id = params.get("simkl_id", "")

    xbmcplugin.setPluginCategory(HANDLE, title)
    xbmcplugin.setContent(HANDLE, "movies")
    addon = xbmcaddon.Addon()

    overview = ""
    vote_average = 0.0
    art_url = simkl_poster_url(simkl_poster) if simkl_poster else None

    if tmdb_id:
        try:
            tmdb = TmdbApi(addon)
            if tmdb.is_configured():
                details = tmdb.movie_details(int(tmdb_id))
                overview = details.get("overview") or ""
                vote_average = details.get("vote_average") or 0.0
                if not year:
                    year = (details.get("release_date") or "")[:4]
                tmdb_art = tmdb_poster_url(details.get("poster_path"))
                if tmdb_art:
                    art_url = tmdb_art
        except Exception as e:
            xbmc.log(f"[WhatsOnStreamer] TMDB movie_details failed: {e}", xbmc.LOGERROR)

    art = {"thumb": art_url, "poster": art_url, "icon": art_url} if art_url else None

    hl_url = build_url(action="open_homelander", title=title, imdb=imdb_id, tmdb=tmdb_id, year=year, media_type="movie")

    local_path = None
    try:
        lf_api = LocalMediaApi()
        if lf_api.is_movies_configured():
            local_path = lf_api.find_movie(title)
    except Exception as e:
        xbmc.log(f"[WhatsOnStreamer] Local movie lookup failed: {e}", xbmc.LOGERROR)

    iptv_ok = False
    try:
        iptv_api = IptvApi()
        if iptv_api.is_vod_configured():
            iptv_ok = iptv_api.is_movie_available(title)
    except Exception as e:
        xbmc.log(f"[WhatsOnStreamer] IPTV movie availability check failed: {e}", xbmc.LOGERROR)

    ad_ok = False
    try:
        ad_api = AllDebridApi()
        if ad_api.is_configured():
            ad_ok = ad_api.is_movie_available(title)
    except Exception as e:
        xbmc.log(f"[WhatsOnStreamer] AllDebrid movie availability check failed: {e}", xbmc.LOGERROR)

    label = f"{title} ({year})" if year else title
    if ad_ok:
        label += "  [COLOR lime]● AD[/COLOR]"
    if local_path:
        label += "  [COLOR dodgerblue]● LF[/COLOR]"
    if iptv_ok:
        label += "  [COLOR orange]● IPTV[/COLOR]"

    # Default click priority: local file -> IPTV -> Homelander (catch-all),
    # same rationale as show_season_episodes.
    if local_path:
        default_url = local_path
        is_playable = True
    elif iptv_ok:
        default_url = build_url(action="play_iptv_movie", title=title)
        is_playable = False
    else:
        default_url = hl_url
        is_playable = False

    ctx = [
        ("Play via AllDebrid", f"RunPlugin({build_url(action='play_alldebrid_movie', title=title)})"),
    ]
    if local_path:
        ctx.append(("Play local file", f"RunPlugin({build_url(action='play_local_movie', title=title)})"))
    ctx.append(("Play via Homelander", f"RunPlugin({hl_url})"))
    ctx.append(("Play via IPTV", f"RunPlugin({build_url(action='play_iptv_movie', title=title)})"))
    if simkl_id:
        ctx.append(("Watch Trailer", f"RunPlugin({build_url(action='play_trailer', title=title, simkl_id=simkl_id, kind='movie')})"))
        ctx.append(("Add to Watchlist", f"RunPlugin({build_url(action='recommended_watchlist', kind='movie', simkl_id=simkl_id, title=title)})"))

    info = {"title": title}
    if year:
        info["year"] = str(year)
    if overview:
        info["plot"] = overview
    if vote_average:
        info["rating"] = float(vote_average)

    add_item(
        label, url=default_url,
        info=info, art=art, context_menu=ctx,
        is_folder=False, is_playable=is_playable,
    )

    end_dir()


_AD_VIDEO_EXTS = {".mkv", ".mp4", ".avi", ".m4v", ".mov", ".wmv", ".ts", ".m2ts"}


def _ad_is_video(filename):
    ext = ("." + filename.rsplit(".", 1)[-1].lower()) if "." in filename else ""
    return ext in _AD_VIDEO_EXTS


# --------------------------
# AllDebrid browser
# --------------------------
def show_alldebrid_menu():
    xbmcplugin.setPluginCategory(HANDLE, "AllDebrid")
    ad = AllDebridApi()
    if not ad.is_configured():
        add_item("AllDebrid API key not set — configure in Settings.")
        end_dir()
        return
    magnets = ad._get_all_magnets()
    add_folder("[COLOR yellow]In Progress[/COLOR]", "alldebrid_inprogress")
    add_folder("[COLOR yellow]Errors[/COLOR]", "alldebrid_errors")
    ready = [m for m in magnets if m.get("statusCode", -1) == 4]
    for m in ready:
        label = m.get("filename", f"Magnet {m.get('id', '?')}")
        size_str = _fmt_bytes(m.get("size", 0))
        url = build_url(action="alldebrid_magnet_files", magnet_id=str(m["id"]), label=label)
        li = xbmcgui.ListItem(label=label, label2=size_str)
        li.setArt({"icon": f"{MEDIA_PATH}/magnet.png", "thumb": f"{MEDIA_PATH}/magnet.png"})
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    if not ready:
        add_item("No ready magnets.")
    end_dir()


def _fmt_bytes(n):
    if not n:
        return "0 B"
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(n) < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} PB"


def show_alldebrid_inprogress():
    xbmcplugin.setPluginCategory(HANDLE, "AllDebrid / In Progress")
    ad = AllDebridApi()
    if not ad.is_configured():
        add_item("AllDebrid API key not set — configure in Settings.")
        end_dir()
        return
    in_progress = [m for m in ad._get_all_magnets() if m.get("statusCode", -1) in (0, 1, 2, 3)]
    if not in_progress:
        add_item("No magnets in progress.")
        end_dir()
        return
    for m in in_progress:
        label = m.get("filename", f"Magnet {m.get('id', '?')}")
        size = m.get("size", 0)
        downloaded = m.get("downloaded", 0)
        speed = m.get("speed", 0)
        pct = m.get("completionPercent") or (round(downloaded / size * 100, 1) if size else 0)
        parts = [_fmt_bytes(size)]
        if pct:
            parts.append(f"{pct}%")
        if speed:
            parts.append(f"{_fmt_bytes(speed)}/s")
        detail = " | ".join(parts)
        li = xbmcgui.ListItem(label=label, label2=detail)
        xbmcplugin.addDirectoryItem(HANDLE, build_url(action="alldebrid_inprogress"), li, isFolder=False)
    end_dir()


def show_alldebrid_errors():
    xbmcplugin.setPluginCategory(HANDLE, "AllDebrid / Errors")
    ad = AllDebridApi()
    if not ad.is_configured():
        add_item("AllDebrid API key not set — configure in Settings.")
        end_dir()
        return
    errors = [m for m in ad._get_all_magnets() if m.get("statusCode", -1) >= 5]
    if not errors:
        add_item("No errored magnets.")
        end_dir()
        return
    for m in errors:
        label = m.get("filename", f"Magnet {m.get('id', '?')}")
        add_item(label, label2=m.get("error") or m.get("status") or "Error")
    end_dir()


def show_alldebrid_magnet_files(params):
    magnet_id = params.get("magnet_id", "")
    parent_label = params.get("label", f"Magnet {magnet_id}")
    xbmcplugin.setPluginCategory(HANDLE, f"AllDebrid / {parent_label}")
    ad = AllDebridApi()
    try:
        files = ad._get_magnet_files(int(magnet_id))
    except Exception as e:
        xbmc.log(f"[WhatsOnStreamer][AllDebrid] magnet files error: {e}", xbmc.LOGERROR)
        add_item("Failed to load files.")
        end_dir()
        return
    video_files = [(fname, link, size) for fname, link, size in files if _ad_is_video(fname)]
    if not video_files:
        add_item("No video files in this magnet.")
        end_dir()
        return
    for fname, link, size in video_files:
        display = fname.rsplit("/", 1)[-1]
        size_str = _fmt_bytes(size) if size else ""
        url = build_url(action="play_alldebrid_link", link=link, title=display)
        li = xbmcgui.ListItem(label=display, label2=size_str)
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)
    end_dir()


_AD_MIME = {
    ".mkv": "video/x-matroska",
    ".mp4": "video/mp4",
    ".avi": "video/x-msvideo",
    ".m4v": "video/mp4",
    ".mov": "video/quicktime",
    ".wmv": "video/x-ms-wmv",
    ".ts":  "video/mp2t",
    ".m2ts": "video/mp2t",
}


def _ad_resolve_and_play(stream_url, title, use_resolved_url=False, user_agent=None,
                          show_title=None, season=None, episode=None, imdb_id=None, tmdb_id=None):
    """Shared playback helper for AllDebrid streams and direct IPTV streams.

    user_agent is only passed for direct IPTV provider URLs — those servers can
    silently reject Kodi's default player UA (empty body, instant EOF from the
    demuxer). AllDebrid's already-resolved CDN links don't need it and shouldn't
    get an unrelated header appended.

    show_title/season/episode are only passed for TV episodes. script.simkl's
    scrobbler (engine.py _detect_item) reads season/episode straight off Kodi's
    own exposed video info if both are > 0, and only falls back to parsing the
    "file" path otherwise — which is useless here since that's a stream URL
    with no show name in it (unlike local files, where the path itself is
    "Show/Season NN/Show SxxEyy.ext" and gets identified that way instead).
    Setting these explicitly is what actually makes IPTV/debrid episodes
    scrobble, not just having a nice display title.

    imdb_id/tmdb_id matter just as much: without a unique ID, script.simkl's
    scrobble goes out as a bare title-string match ("shows": [{"title": ...,
    "ids": {}}]), which SIMKL accepts but doesn't reliably resolve into a real
    watched entry (confirmed - it silently didn't show up in SIMKL, unlike the
    equivalent ID-matched local-file scrobble). Both are accepted since SIMKL's
    own /search/tv and /search/movie endpoints never return an imdb id (only
    simkl_id/tmdb) - confirmed live - so search-originated playback would have
    no usable ID at all if this only took imdb.
    """
    ext = ("." + title.rsplit(".", 1)[-1].lower()) if "." in title else ""
    mime = _AD_MIME.get(ext, "")
    play_path = f"{stream_url}|User-Agent={urllib.parse.quote(user_agent)}" if user_agent else stream_url
    li = xbmcgui.ListItem(label=title, path=play_path)
    if show_title and season and episode:
        info = {
            "title": title, "tvshowtitle": show_title,
            "season": season, "episode": episode, "mediatype": "episode",
        }
        if imdb_id:
            info["imdbnumber"] = imdb_id
        li.setInfo("video", info)
        unique_ids = {}
        if imdb_id:
            unique_ids["imdb"] = imdb_id
        if tmdb_id:
            unique_ids["tmdb"] = str(tmdb_id)
        if unique_ids:
            # setInfo's "imdbnumber" alone tags the JSON-RPC uniqueid as type
            # "unknown", not "imdb" (confirmed live) - script.simkl's ids lookup
            # only checks the named imdb/tvdb/tmdb keys, so "unknown" is invisible
            # to it. setUniqueIDs is what actually labels it correctly.
            li.getVideoInfoTag().setUniqueIDs(unique_ids, "imdb" if imdb_id else "tmdb")
    else:
        li.setInfo("video", {"title": title})
    li.setContentLookup(False)
    if mime:
        li.setMimeType(mime)
    if use_resolved_url:
        xbmcplugin.setResolvedUrl(HANDLE, True, li)
    else:
        xbmc.Player().play(play_path, li)


def play_alldebrid_link(params):
    link = params.get("link", "")
    title = params.get("title", "")
    if not link:
        xbmcgui.Dialog().notification("AllDebrid", "No link provided", xbmcgui.NOTIFICATION_ERROR, 3000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    ad = AllDebridApi()
    if not ad.is_configured():
        xbmcgui.Dialog().notification("AllDebrid", "API key not set — add it in Settings", xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    try:
        stream_url = ad.unlock_link(link)
    except Exception as e:
        xbmc.log(f"[WhatsOnStreamer][AllDebrid] unlock error: {e}", xbmc.LOGERROR)
        stream_url = None
    if not stream_url:
        xbmcgui.Dialog().notification("AllDebrid", f"Failed to unlock: {title}", xbmcgui.NOTIFICATION_ERROR, 3000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    _ad_resolve_and_play(stream_url, title, use_resolved_url=True)


# --------------------------
# AllDebrid playback
# --------------------------
def play_alldebrid(params):
    title = params.get("title", "")
    try:
        season = int(params.get("season", 0))
        episode = int(params.get("episode", 0))
    except (ValueError, TypeError):
        return

    try:
        ad_api = AllDebridApi()
        if not ad_api.is_configured():
            xbmcgui.Dialog().notification("AllDebrid", "API key not set — add it in Settings", xbmcgui.NOTIFICATION_WARNING, 3000)
            return
        stream_url, fname = ad_api.find_episode(title, season, episode)
    except Exception as e:
        xbmc.log(f"[WhatsOnStreamer][AllDebrid] find_episode error: {e}", xbmc.LOGERROR)
        stream_url, fname = None, None

    if not stream_url:
        xbmcgui.Dialog().notification(
            "AllDebrid",
            f"No match: {title} S{season:02d}E{episode:02d}",
            xbmcgui.NOTIFICATION_WARNING,
            3000,
        )
        return

    label = fname or f"{title} S{season:02d}E{episode:02d}"
    _ad_resolve_and_play(stream_url, label, show_title=title, season=season, episode=episode,
                          imdb_id=params.get("imdb", ""), tmdb_id=params.get("tmdb", ""))


# --------------------------
# IPTV (Xtream series) playback
# --------------------------
def play_iptv(params):
    title = params.get("title", "")
    try:
        season = int(params.get("season", 0))
        episode = int(params.get("episode", 0))
    except (ValueError, TypeError):
        return

    try:
        iptv_api = IptvApi()
        if not iptv_api.is_configured():
            xbmcgui.Dialog().notification("IPTV", "Provider not set — add it in Settings", xbmcgui.NOTIFICATION_WARNING, 3000)
            return
        stream_url, display = iptv_api.find_episode(title, season, episode)
    except Exception as e:
        xbmc.log(f"[WhatsOnStreamer][IPTV] find_episode error: {e}", xbmc.LOGERROR)
        stream_url, display = None, None

    if not stream_url:
        xbmcgui.Dialog().notification(
            "IPTV",
            f"No match: {title} S{season:02d}E{episode:02d}",
            xbmcgui.NOTIFICATION_WARNING,
            3000,
        )
        return

    label = display or f"{title} S{season:02d}E{episode:02d}"
    _ad_resolve_and_play(stream_url, label, user_agent=get_iptv_ua(),
                          show_title=title, season=season, episode=episode,
                          imdb_id=params.get("imdb", ""), tmdb_id=params.get("tmdb", ""))


# --------------------------
# Context-menu "Play" shortcut from a show list (New Episodes / Upcoming) -
# same local -> IPTV -> Homelander priority play_movie_default() uses for
# movies, jumping straight to the next episode rather than navigating into
# the season/episode screen first.
# --------------------------
def play_episode_default(params):
    title = params.get("title", "")
    try:
        season = int(params.get("season", 0))
        episode = int(params.get("episode", 0))
    except (ValueError, TypeError):
        return

    try:
        lf_api = LocalMediaApi()
        if lf_api.is_configured() and lf_api.find_episode(title, season, episode):
            play_local(params)
            return
    except Exception as e:
        xbmc.log(f"[WhatsOnStreamer] Local episode lookup failed: {e}", xbmc.LOGERROR)

    try:
        iptv_api = IptvApi()
        if iptv_api.is_configured() and episode in iptv_api.get_available_episodes(title, season):
            play_iptv(params)
            return
    except Exception as e:
        xbmc.log(f"[WhatsOnStreamer] IPTV episode availability check failed: {e}", xbmc.LOGERROR)

    open_homelander({**params, "next": f"S{season:02d}E{episode:02d}"})


# --------------------------
# Local file playback
# --------------------------
def play_local(params):
    title = params.get("title", "")
    try:
        season = int(params.get("season", 0))
        episode = int(params.get("episode", 0))
    except (ValueError, TypeError):
        return

    lf_api = LocalMediaApi()
    if not lf_api.is_configured():
        xbmcgui.Dialog().notification("Local Media", "Base path not set — add it in Settings", xbmcgui.NOTIFICATION_WARNING, 3000)
        return

    file_path = lf_api.find_episode(title, season, episode)
    if not file_path:
        xbmcgui.Dialog().notification(
            "Local Media",
            f"No file found: {title} S{season:02d}E{episode:02d}",
            xbmcgui.NOTIFICATION_WARNING,
            3000,
        )
        return

    label = f"{title} S{season:02d}E{episode:02d}"
    li = xbmcgui.ListItem(label=label, path=file_path)
    li.setInfo("video", {"title": label})
    li.setProperty("IsPlayable", "true")
    xbmc.Player().play(file_path, li)


# --------------------------
# Movie playback (AllDebrid / IPTV / local) — same shape as the episode
# handlers above, just keyed by title alone (no season/episode).
# --------------------------
def play_alldebrid_movie(params):
    title = params.get("title", "")
    try:
        ad_api = AllDebridApi()
        if not ad_api.is_configured():
            xbmcgui.Dialog().notification("AllDebrid", "API key not set — add it in Settings", xbmcgui.NOTIFICATION_WARNING, 3000)
            return
        stream_url, fname = ad_api.find_movie(title)
    except Exception as e:
        xbmc.log(f"[WhatsOnStreamer][AllDebrid] find_movie error: {e}", xbmc.LOGERROR)
        stream_url, fname = None, None

    if not stream_url:
        xbmcgui.Dialog().notification("AllDebrid", f"No match: {title}", xbmcgui.NOTIFICATION_WARNING, 3000)
        return

    label = fname or title
    _ad_resolve_and_play(stream_url, label)


def play_iptv_movie(params):
    title = params.get("title", "")
    try:
        iptv_api = IptvApi()
        if not iptv_api.is_vod_configured():
            xbmcgui.Dialog().notification("IPTV", "Provider not set — add it in Settings", xbmcgui.NOTIFICATION_WARNING, 3000)
            return
        stream_url, display = iptv_api.find_movie(title)
    except Exception as e:
        xbmc.log(f"[WhatsOnStreamer][IPTV] find_movie error: {e}", xbmc.LOGERROR)
        stream_url, display = None, None

    if not stream_url:
        xbmcgui.Dialog().notification("IPTV", f"No match: {title}", xbmcgui.NOTIFICATION_WARNING, 3000)
        return

    label = display or title
    _ad_resolve_and_play(stream_url, label, user_agent=get_iptv_ua())


def play_local_movie(params):
    title = params.get("title", "")

    lf_api = LocalMediaApi()
    if not lf_api.is_movies_configured():
        xbmcgui.Dialog().notification("Local Media", "Movies base path not set — add it in Settings", xbmcgui.NOTIFICATION_WARNING, 3000)
        return

    file_path = lf_api.find_movie(title)
    if not file_path:
        xbmcgui.Dialog().notification("Local Media", f"No file found: {title}", xbmcgui.NOTIFICATION_WARNING, 3000)
        return

    li = xbmcgui.ListItem(label=title, path=file_path)
    li.setInfo("video", {"title": title})
    li.setProperty("IsPlayable", "true")
    xbmc.Player().play(file_path, li)


# --------------------------
# Context-menu "Play" shortcut from a movie list - same local -> IPTV ->
# Homelander priority show_movie_item() uses, just skipping straight to
# playback instead of navigating into the single-item screen first.
# --------------------------
def play_movie_default(params):
    title = params.get("title", "")

    try:
        lf_api = LocalMediaApi()
        if lf_api.is_movies_configured() and lf_api.find_movie(title):
            play_local_movie(params)
            return
    except Exception as e:
        xbmc.log(f"[WhatsOnStreamer] Local movie lookup failed: {e}", xbmc.LOGERROR)

    try:
        iptv_api = IptvApi()
        if iptv_api.is_vod_configured() and iptv_api.is_movie_available(title):
            play_iptv_movie(params)
            return
    except Exception as e:
        xbmc.log(f"[WhatsOnStreamer] IPTV movie availability check failed: {e}", xbmc.LOGERROR)

    open_homelander({**params, "media_type": "movie"})


# --------------------------
# Trailer playback
# --------------------------
def play_trailer(params):
    title     = params.get("title", "")
    kind      = params.get("kind", "show")
    addon     = xbmcaddon.Addon()
    api       = SimklApi(addon)
    simkl_id  = _resolve_simkl_id(params, api)
    youtube_id = None

    if simkl_id:
        try:
            details = api.get_movie_details_full(int(simkl_id)) if kind == "movie" else api.get_show_details_full(int(simkl_id))
            # SIMKL extended=full returns trailer as a bare YouTube video ID string
            youtube_id = details.get("trailer") or details.get("youtube")
            if not youtube_id:
                for t in (details.get("trailers") or []):
                    youtube_id = t.get("youtube") or t.get("id") if isinstance(t, dict) else None
                    if youtube_id:
                        break
        except Exception as e:
            xbmc.log(f"[WhatsOnStreamer] Trailer lookup failed: {e}", xbmc.LOGERROR)

    if youtube_id:
        xbmc.log(f"[WhatsOnStreamer] Playing trailer youtube_id={youtube_id} for {title}", xbmc.LOGINFO)
        # PlayMedia, not RunPlugin - RunPlugin invokes the target addon with no
        # resolve handle (Handle: -1 in kodi.log), which crashes some versions of
        # plugin.video.youtube before they ever get to resolve the stream.
        xbmc.executebuiltin(f'PlayMedia("plugin://plugin.video.youtube/play/?video_id={youtube_id}")')
    else:
        xbmc.log(f"[WhatsOnStreamer] No SIMKL trailer for {title!r}, falling back to YouTube search", xbmc.LOGINFO)
        q = urllib.parse.quote(f"{title} official trailer")
        xbmc.executebuiltin(f'ActivateWindow(10025,"plugin://plugin.video.youtube/kodion/search/query/?q={q}",return)')


# --------------------------
# Router
# --------------------------
def router():
    params = get_params()
    action = params.get("action", "root")
    log(f"Action: {action}")

    if action == "root":
        show_root_menu()
    elif action == "whatsupnext_root":
        show_whatsupnext_menu()
    elif action == "tools_root":
        show_tools_menu()
    elif action == "settings":
        ADDON.openSettings()
    elif action == "settings_import":
        legacy_import.run()
    elif action == "settings_reset":
        settings_reset.confirm_and_reset()
    elif action == "svc_update":
        xbmc.executebuiltin('RunScript(special://home/addons/plugin.video.whatsonstreamer/service.py,manual)')
    elif action == "svc_warm_whatsupnext":
        xbmc.executebuiltin('RunScript(special://home/addons/plugin.video.whatsonstreamer/service.py,warm_whatsupnext)')
    elif action == "livetv_root":
        livetv.list_root()
    elif action == "livetv_build_info":
        livetv.show_build_info()
    elif action == "iptv_manage_profiles":
        iptv_profiles.manage()
    elif action == "livetv_test":
        livetv.test_connection()
    elif action == "livetv_test_local":
        livetv.test_local_files()
    elif action == "livetv_on_now":
        livetv.list_on_now()
    elif action == "livetv_coming_up":
        livetv.list_coming_up()
    elif action == "livetv_favs":
        livetv.list_favourites()
    elif action == "livetv_recent":
        livetv.list_recent()
    elif action == "livetv_recent_clear":
        livetv.clear_recent(); xbmc.executebuiltin('Container.Refresh')
    elif action == "livetv_fav_clear":
        livetv.clear_favourites(); xbmc.executebuiltin('Container.Refresh')
    elif action == "livetv_fav_add":
        livetv.fav_add_index(params.get('i', '')); xbmc.executebuiltin('Container.Refresh')
    elif action == "livetv_fav_add_url":
        livetv.fav_add_url(params.get('u', ''), params.get('n', '')); xbmc.executebuiltin('Container.Refresh')
    elif action == "livetv_fav_remove_url":
        livetv.fav_remove_url(params.get('u', '')); xbmc.executebuiltin('Container.Refresh')
    elif action == "livetv_groups":
        livetv.list_groups()
    elif action == "livetv_group":
        livetv.list_group(params.get('name', ''), int(params.get('start', '0') or '0'))
    elif action == "livetv_all":
        livetv.list_all_channels(int(params.get('start', '0') or '0'))
    elif action == "livetv_search":
        livetv.do_search()
    elif action == "livetv_search_results":
        livetv.list_search_results()
    elif action == "livetv_search_epg":
        livetv.do_search_epg()
    elif action == "livetv_search_epg_results":
        livetv.list_search_epg_results()
    elif action == "livetv_schedule_add":
        livetv.do_schedule_add(params.get('u', ''), params.get('n', ''), params.get('lg', ''),
                                params.get('t', ''), params.get('start', ''), params.get('stop', ''))
    elif action == "livetv_scheduled":
        livetv.list_scheduled_events()
    elif action == "livetv_schedule_remove":
        livetv.do_schedule_remove(params.get('id', ''))
    elif action == "livetv_play":
        livetv.play_channel_by_index(params.get('i', ''), params.get('auto', ''))
    elif action == "livetv_play_url":
        livetv.play_channel_by_url(params.get('u', ''), params.get('n', ''), params.get('auto', ''))
    elif action == "livetv_play_m3u":
        livetv.play_m3u(params.get('u', ''), params.get('n', ''))
    elif action == "livetv_refresh":
        livetv.load_playlist_index(force=True); xbmc.executebuiltin('Container.Refresh')
    elif action == "livetv_refresh_epg":
        _idx = livetv.load_playlist_index(force=False)
        livetv.load_epg_now_next(force=True, playlist_index=_idx)
        xbmc.executebuiltin('Container.Refresh')
    elif action == "new":
        show_new_episodes()
    elif action == "upcoming":
        show_upcoming()
    elif action == "movies":
        show_movies()
    elif action == "add_content_menu":
        show_add_content_menu()
    elif action == "add_movies_menu":
        show_add_movies_menu()
    elif action == "add_series_menu":
        show_add_series_menu()
    elif action == "movie_genres_menu":
        show_movie_genres_menu()
    elif action == "tv_genres_menu":
        show_tv_genres_menu()
    elif action == "movie_genre_titles":
        show_movie_genre_titles(params)
    elif action == "tv_genre_titles":
        show_tv_genre_titles(params)
    elif action == "recommended_shows":
        show_recommended_shows()
    elif action == "recommended_movies":
        show_recommended_movies()
    elif action == "recommended_remove":
        recommended_remove(params); xbmc.executebuiltin('Container.Refresh')
    elif action == "recommended_watchlist":
        recommended_watchlist(params); xbmc.executebuiltin('Container.Refresh')
    elif action == "recommended_watched":
        recommended_watched(params); xbmc.executebuiltin('Container.Refresh')
    elif action == "mark_episode_watched":
        mark_episode_watched(params); xbmc.executebuiltin('Container.Refresh')
    elif action == "mark_season_watched":
        mark_season_watched(params); xbmc.executebuiltin('Container.Refresh')
    elif action == "search_menu":
        show_search_menu()
    elif action == "search_series":
        search_series()
    elif action == "search_movies":
        search_movies()
    elif action == "help":
        show_help()
    elif action == "auth":
        show_auth()
    elif action == "log_bug":
        log_bug(params)
    elif action == "show_seasons":
        show_seasons(params)
    elif action == "show_season_episodes":
        show_season_episodes(params)
    elif action == "show_movie":
        show_movie_item(params)
    elif action == "play_trailer":
        play_trailer(params)
    elif action == "open_homelander":
        open_homelander(params)
    elif action == "alldebrid_menu":
        show_alldebrid_menu()
    elif action == "alldebrid_inprogress":
        show_alldebrid_inprogress()
    elif action == "alldebrid_errors":
        show_alldebrid_errors()
    elif action == "alldebrid_magnet_files":
        show_alldebrid_magnet_files(params)
    elif action == "play_alldebrid_link":
        play_alldebrid_link(params)
    elif action == "play_alldebrid":
        play_alldebrid(params)
    elif action == "play_local":
        play_local(params)
    elif action == "play_iptv":
        play_iptv(params)
    elif action == "play_episode_default":
        play_episode_default(params)
    elif action == "play_alldebrid_movie":
        play_alldebrid_movie(params)
    elif action == "play_local_movie":
        play_local_movie(params)
    elif action == "play_iptv_movie":
        play_iptv_movie(params)
    elif action == "play_movie_default":
        play_movie_default(params)
    elif action.startswith("show_"):
        show_show_info(action)
    else:
        xbmcgui.Dialog().notification(
            "WhatsOnStreamer",
            f"Unknown action: {action}",
            xbmcgui.NOTIFICATION_ERROR
        )
        show_root_menu()


if __name__ == "__main__":
    router()