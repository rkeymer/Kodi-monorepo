import os
import re
from resources.lib.cache import DiskCache

try:
    import xbmc
    import xbmcaddon
    def _log(msg):
        xbmc.log(f"[WhatsOnStreamer][LocalMedia] {msg}", xbmc.LOGINFO)
except ImportError:
    def _log(msg):
        print(f"[LocalMedia] {msg}")

_cache_lf = DiskCache("local_media", ttl=120)  # 2 min

_VIDEO_EXTS = {".mkv", ".mp4", ".avi", ".m4v", ".mov", ".wmv", ".ts", ".m2ts"}


def _se_from_filename(filename):
    m = re.search(r"[Ss](\d{1,2})[Ee](\d{1,2})", filename)
    if m:
        return int(m.group(1)), int(m.group(2))
    return None


def _is_video(filename):
    ext = ("." + filename.rsplit(".", 1)[-1].lower()) if "." in filename else ""
    return ext in _VIDEO_EXTS


def _normalize(title):
    s = str(title).lower()
    s = re.sub(r"[^\w\s]", " ", s)
    return re.sub(r"\s+", " ", s).strip()


class LocalMediaApi:

    def __init__(self):
        try:
            addon = xbmcaddon.Addon()
            self._base_path = addon.getSettingString("local_media_path").strip()
            self._movies_base_path = addon.getSettingString("local_movies_path").strip()
        except Exception:
            self._base_path = ""
            self._movies_base_path = ""

    def is_configured(self):
        return bool(self._base_path) and os.path.isdir(self._base_path)

    def is_movies_configured(self):
        return bool(self._movies_base_path) and os.path.isdir(self._movies_base_path)

    def _find_show_dir(self, show_title):
        norm_target = _normalize(show_title)
        try:
            entries = os.listdir(self._base_path)
        except OSError:
            return None
        best, best_score = None, 0.0
        for entry in entries:
            full = os.path.join(self._base_path, entry)
            if not os.path.isdir(full):
                continue
            norm_entry = _normalize(entry)
            if norm_entry == norm_target:
                return full
            if norm_target in norm_entry or norm_entry in norm_target:
                score = len(min(norm_target, norm_entry, key=len)) / max(len(norm_target), len(norm_entry), 1)
                if score > best_score:
                    best_score, best = score, full
        if best and best_score >= 0.7:
            return best
        return None

    def _find_season_dir(self, show_dir, season):
        candidates = [
            f"Season {season:02d}",
            f"Season {season}",
            f"S{season:02d}",
        ]
        try:
            entries = os.listdir(show_dir)
        except OSError:
            return None
        for candidate in candidates:
            for entry in entries:
                if entry.lower() == candidate.lower():
                    return os.path.join(show_dir, entry)
        return None

    def get_available_episodes(self, show_title, season):
        cache_key = f"{show_title}:{season}"
        cached = _cache_lf.get(cache_key)
        if cached is not None:
            _log(f"Local episodes from cache for '{show_title}' S{season:02d}: {sorted(cached)}")
            return set(cached)
        show_dir = self._find_show_dir(show_title)
        if not show_dir:
            _log(f"No local folder for '{show_title}'")
            return set()
        season_dir = self._find_season_dir(show_dir, int(season))
        if not season_dir:
            _log(f"No Season {season} folder in '{show_dir}'")
            return set()
        available = set()
        try:
            for fname in os.listdir(season_dir):
                if _is_video(fname):
                    se = _se_from_filename(fname)
                    if se and se[0] == int(season):
                        available.add(se[1])
        except OSError as e:
            _log(f"Error reading season dir: {e}")
        _log(f"Local episodes for '{show_title}' S{season:02d}: {sorted(available)}")
        _cache_lf.set(cache_key, list(available))
        return available

    def get_available_episodes_with_paths(self, show_title, season):
        """Returns {ep_num: file_path} for every local video file found in the season dir."""
        cache_key = f"{show_title}:{season}:paths"
        cached = _cache_lf.get(cache_key)
        if cached is not None:
            return {int(k): v for k, v in cached.items()}
        show_dir = self._find_show_dir(show_title)
        if not show_dir:
            return {}
        season_dir = self._find_season_dir(show_dir, int(season))
        if not season_dir:
            return {}
        result = {}
        try:
            for fname in os.listdir(season_dir):
                if _is_video(fname):
                    se = _se_from_filename(fname)
                    if se and se[0] == int(season):
                        result[se[1]] = os.path.join(season_dir, fname)
        except OSError as e:
            _log(f"Error reading season dir: {e}")
        _cache_lf.set(cache_key, {str(k): v for k, v in result.items()})
        return result

    def find_episode(self, show_title, season, episode):
        show_dir = self._find_show_dir(show_title)
        if not show_dir:
            return None
        season_dir = self._find_season_dir(show_dir, int(season))
        if not season_dir:
            return None
        target = (int(season), int(episode))
        try:
            for fname in os.listdir(season_dir):
                if _is_video(fname) and _se_from_filename(fname) == target:
                    return os.path.join(season_dir, fname)
        except OSError:
            return None
        return None

    # ------------------------------------------------------------------
    # Movies — entries in the movies base folder are either a video file
    # directly, or a folder (picks the largest video file inside, i.e. the
    # feature film rather than a sample/extra).
    # ------------------------------------------------------------------
    def _find_movie_entry(self, title):
        norm_target = _normalize(title)
        try:
            entries = os.listdir(self._movies_base_path)
        except OSError:
            return None, False
        best, best_score, best_is_dir = None, 0.0, False
        for entry in entries:
            full = os.path.join(self._movies_base_path, entry)
            is_dir = os.path.isdir(full)
            if not is_dir and not _is_video(entry):
                continue
            norm_entry = _normalize(entry)
            if norm_entry == norm_target:
                return full, is_dir
            if norm_target in norm_entry or norm_entry in norm_target:
                score = len(min(norm_target, norm_entry, key=len)) / max(len(norm_target), len(norm_entry), 1)
                if score > best_score:
                    best_score, best, best_is_dir = score, full, is_dir
        if best and best_score >= 0.7:
            return best, best_is_dir
        return None, False

    def find_movie(self, title):
        entry, is_dir = self._find_movie_entry(title)
        if not entry:
            return None
        if not is_dir:
            return entry
        try:
            candidates = [os.path.join(entry, f) for f in os.listdir(entry) if _is_video(f)]
        except OSError:
            return None
        if not candidates:
            return None
        return max(candidates, key=os.path.getsize)
